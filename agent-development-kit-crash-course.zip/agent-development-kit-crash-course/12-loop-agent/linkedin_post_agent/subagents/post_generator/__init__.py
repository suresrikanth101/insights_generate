"""
LinkedIn Post Generator Agent Package

This package provides an agent for generating the initial LinkedIn post.
"""

from .agent import initial_post_generator
