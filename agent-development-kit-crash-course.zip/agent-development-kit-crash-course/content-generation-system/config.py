"""
Configuration for Content Generation System (VBG multi-agent)
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Model configuration
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
TEMPERATURE = float(os.getenv("MODEL_TEMPERATURE", "0.7"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "8192"))

# Redis configuration
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
SESSION_TTL = int(os.getenv("SESSION_TTL", "3600"))

# API configuration
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise ValueError("GOOGLE_API_KEY environment variable is required")

# Content configuration (only for supported types)
EMAIL_MAX_LENGTH = int(os.getenv("EMAIL_MAX_LENGTH", "500"))
SOCIAL_MAX_LENGTH = int(os.getenv("SOCIAL_MAX_LENGTH", "280"))
LONG_FORM_MIN_LENGTH = int(os.getenv("LONG_FORM_MIN_LENGTH", "1000")) 