#!/bin/bash

# Streaming Multi-Agent Content Generation System Startup Script

echo "🚀 Starting VBG Content Generation Streaming Server..."
echo "=================================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+ first."
    exit 1
fi

# Check if Redis is running
if ! command -v redis-cli &> /dev/null; then
    echo "⚠️  Redis CLI not found. Make sure Redis is installed and running."
    echo "   You can start Redis with: docker run -d -p 6379:6379 redis:alpine"
else
    if ! redis-cli ping &> /dev/null; then
        echo "⚠️  Redis is not running. Please start Redis first."
        echo "   You can start Redis with: docker run -d -p 6379:6379 redis:alpine"
    else
        echo "✅ Redis is running"
    fi
fi

# Check if .env file exists
if [ ! -f "../.env" ]; then
    echo "⚠️  .env file not found. Creating from example..."
    if [ -f "../.env.example" ]; then
        cp ../.env.example ../.env
        echo "✅ Created .env file. Please edit it with your API key."
    else
        echo "❌ .env.example not found. Please create .env file manually."
        exit 1
    fi
fi

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

echo "📦 Activating virtual environment..."
source venv/bin/activate

echo "📦 Installing dependencies..."
pip install -r requirements.txt

echo "🌐 Starting streaming server..."
echo "   Web Interface: http://localhost:8000"
echo "   API Docs: http://localhost:8000/docs"
echo "   Health Check: http://localhost:8000/api/v1/health"
echo ""
echo "Press Ctrl+C to stop the server"
echo "=================================================="

# Start the server
python main.py 