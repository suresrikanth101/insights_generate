#!/usr/bin/env python3
"""
Test script for the Streaming Content Generation API
Demonstrates real-time streaming capabilities.
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime

# API Configuration
API_BASE_URL = "http://localhost:8000"
STREAMING_ENDPOINT = f"{API_BASE_URL}/api/v1/generate/streaming"

async def test_health_check():
    """Test the health check endpoint."""
    print("🔍 Testing health check...")
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{API_BASE_URL}/api/v1/health") as response:
            if response.status == 200:
                data = await response.json()
                print("✅ Health check passed")
                print(f"   Status: {data['status']}")
                print(f"   Services: {data['services']}")
                return True
            else:
                print(f"❌ Health check failed: {response.status}")
                return False

async def test_streaming_generation(payload):
    """Test streaming content generation."""
    print(f"\n🚀 Testing streaming content generation...")
    print(f"   Query: {payload['query']}")
    print(f"   Content Type: {payload.get('content_type', 'Auto-detect')}")
    
    start_time = time.time()
    session_id = None
    content_type = None
    final_content = ""
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(STREAMING_ENDPOINT, json=payload) as response:
                if response.status != 200:
                    print(f"❌ Streaming request failed: {response.status}")
                    return None
                
                print("📡 Receiving streaming response...")
                
                async for line in response.content:
                    line = line.decode('utf-8').strip()
                    
                    if line.startswith('data: '):
                        try:
                            data = json.loads(line[6:])
                            
                            if data.get('status') == 'processing':
                                print(f"   ⏳ {data.get('message', 'Processing...')}")
                                if data.get('session_id'):
                                    session_id = data['session_id']
                                    
                            elif data.get('mime_type') == 'text/plain':
                                if data.get('partial'):
                                    # Print partial content
                                    print(f"   📝 Partial: {data['data'][:50]}...")
                                    final_content += data['data']
                                elif data.get('final'):
                                    # Final content received
                                    print(f"   ✅ Final content received ({len(data['data'])} chars)")
                                    final_content = data['data']
                                    
                            elif data.get('mime_type') == 'application/json':
                                if data.get('summary'):
                                    summary = json.loads(data['data'])
                                    content_type = summary.get('content_type')
                                    print(f"   📊 Content Type: {content_type}")
                                    print(f"   📊 Variants: {summary.get('variants_count', 0)}")
                                    print(f"   📊 Agent: {summary.get('agent_name', 'Unknown')}")
                                    
                            elif data.get('turn_complete'):
                                print("   🎉 Generation completed!")
                                break
                                
                            elif data.get('error'):
                                print(f"   ❌ Error: {data['error']}")
                                break
                                
                        except json.JSONDecodeError as e:
                            print(f"   ⚠️  Error parsing stream data: {e}")
                            continue
                
                processing_time = time.time() - start_time
                print(f"\n📈 Results:")
                print(f"   Session ID: {session_id}")
                print(f"   Content Type: {content_type}")
                print(f"   Processing Time: {processing_time:.2f}s")
                print(f"   Content Length: {len(final_content)} characters")
                
                # Try to parse as JSON for structured display
                try:
                    parsed_content = json.loads(final_content)
                    print(f"   ✅ Valid JSON response")
                    
                    # Display content summary
                    if content_type == 'email_campaign':
                        summary = parsed_content.get('campaign_summary', {})
                        print(f"   📧 Campaign: {summary.get('campaign_title', 'N/A')}")
                        print(f"   📧 Variants: {summary.get('generated_variants', 0)}")
                        
                    elif content_type == 'social_media':
                        posts = parsed_content.get('social_media_posts', [])
                        platforms = set(post.get('platform', 'Unknown') for post in posts)
                        print(f"   🌐 Platforms: {', '.join(platforms)}")
                        print(f"   🌐 Posts: {len(posts)}")
                        
                    elif content_type == 'long_form':
                        articles = parsed_content.get('long_form_content', [])
                        print(f"   📝 Articles: {len(articles)}")
                        if articles:
                            first_article = articles[0]
                            print(f"   📝 Title: {first_article.get('title', 'N/A')[:50]}...")
                            
                except json.JSONDecodeError:
                    print(f"   📄 Raw text response (not JSON)")
                
                return {
                    'session_id': session_id,
                    'content_type': content_type,
                    'processing_time': processing_time,
                    'content': final_content
                }
                
    except Exception as e:
        print(f"❌ Streaming error: {e}")
        return None

async def test_session_info(session_id):
    """Test getting session information."""
    if not session_id:
        return
        
    print(f"\n📊 Testing session info for {session_id}...")
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{API_BASE_URL}/api/v1/sessions/{session_id}") as response:
            if response.status == 200:
                session_info = await response.json()
                print("✅ Session info retrieved!")
                print(f"   Created: {session_info['created_at']}")
                print(f"   Last Accessed: {session_info['last_accessed']}")
                
                # Show content stats
                state = session_info.get('state', {})
                content_stats = state.get('content_stats', {})
                if content_stats:
                    print(f"   Total Generated: {content_stats.get('total_generated', 0)}")
                    print(f"   Email Campaigns: {content_stats.get('email_campaigns', 0)}")
                    print(f"   Social Posts: {content_stats.get('social_posts', 0)}")
                    print(f"   Long Form: {content_stats.get('long_form_content', 0)}")
            else:
                print(f"❌ Session info failed: {response.status}")

async def main():
    """Main test function."""
    print("🧪 STREAMING CONTENT GENERATION API TEST")
    print("=" * 60)
    
    # Test health check first
    health_ok = await test_health_check()
    if not health_ok:
        print("❌ Health check failed. Make sure the server is running.")
        return
    
    # Test payloads
    test_payloads = [
        {
            "query": "Generate an email campaign about Verizon 5G Business Internet for small businesses",
            "document": "Focus on speed, reliability, and business benefits. Emphasize cost-effectiveness.",
            "temperature": 0.7,
            "user_id": "test_streaming_user_001",
            "content_type": "email",
            "campaign_theme": "5G Business Internet",
            "target_audience": "small_business",
            "tone": "professional"
        },
        {
            "query": "Create social media posts about Verizon cloud security solutions",
            "document": "Emphasize enterprise-grade security and compliance features.",
            "temperature": 0.8,
            "user_id": "test_streaming_user_002",
            "content_type": "social",
            "campaign_theme": "Cloud Security",
            "target_audience": "enterprise",
            "tone": "authoritative"
        },
        {
            "query": "Write a blog post about digital transformation with Verizon solutions",
            "document": "Focus on B2B digital transformation journey and ROI.",
            "temperature": 0.6,
            "user_id": "test_streaming_user_003",
            "content_type": "long_form",
            "campaign_theme": "Digital Transformation",
            "target_audience": "business",
            "tone": "educational"
        }
    ]
    
    results = []
    
    for i, payload in enumerate(test_payloads, 1):
        print(f"\n{'='*20} Test {i} {'='*20}")
        result = await test_streaming_generation(payload)
        if result:
            results.append(result)
            await test_session_info(result['session_id'])
        
        # Small delay between tests
        await asyncio.sleep(2)
    
    print(f"\n{'='*60}")
    print("✅ STREAMING API TESTING COMPLETED")
    print(f"   Successful requests: {len(results)}")
    print(f"   Average processing time: {sum(r['processing_time'] for r in results) / len(results):.2f}s")
    print("=" * 60)
    
    # Summary
    if results:
        print("\n📊 Test Summary:")
        for i, result in enumerate(results, 1):
            print(f"   Test {i}: {result['content_type']} ({result['processing_time']:.2f}s)")

if __name__ == "__main__":
    asyncio.run(main()) 