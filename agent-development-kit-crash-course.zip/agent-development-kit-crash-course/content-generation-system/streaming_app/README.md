# Streaming Multi-Agent Content Generation System

A real-time streaming API for Verizon Business Group content generation using Google ADK with multi-agent architecture and Server-Sent Events (SSE).

## 🚀 Features

### Real-time Streaming
- **Server-Sent Events (SSE)**: Real-time streaming responses
- **Partial Updates**: See content being generated in real-time
- **Live Status Updates**: Processing status and progress indicators
- **Web Interface**: Beautiful, responsive web UI for testing

### Multi-Agent Architecture
- **Root Agent**: Delegates to specialized sub-agents
- **Email Agent**: Generates email campaigns with multiple variants
- **Social Media Agent**: Creates platform-specific social media posts
- **Long-form Agent**: Produces comprehensive blog posts and articles

### Content Types Supported
- **📧 Email Campaigns**: Professional B2B email campaigns with subject lines, preview text, and CTAs
- **🌐 Social Media Posts**: Platform-optimized posts for Facebook, Twitter, LinkedIn
- **📝 Long-form Content**: Comprehensive blog posts with structured sections

## 🏗️ Architecture

```
streaming_app/
├── main.py                 # FastAPI streaming server
├── static/
│   └── index.html         # Web interface
├── test_streaming.py      # Async test script
├── requirements.txt       # Dependencies
└── README.md             # This file
```

## 🛠️ Installation

### Prerequisites
- Python 3.8+
- Redis server
- Google Gemini API key

### Setup

1. **Install dependencies:**
```bash
cd streaming_app
pip install -r requirements.txt
```

2. **Set up environment variables:**
```bash
# Create .env file in parent directory
cp ../.env.example ../.env

# Edit .env with your settings
GOOGLE_API_KEY=your_gemini_api_key_here
REDIS_URL=redis://localhost:6379
SESSION_TTL=3600
```

3. **Start Redis server:**
```bash
# Using Docker
docker run -d -p 6379:6379 redis:alpine

# Or install Redis locally
# brew install redis  # macOS
# sudo apt-get install redis-server  # Ubuntu
```

## 🎯 Usage

### Start the Streaming Server
```bash
cd streaming_app
python main.py
```

The server will be available at:
- **Web Interface**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/api/v1/health

### Web Interface
1. Open http://localhost:8000 in your browser
2. Fill in the content generation form
3. Click "Generate Content" to see real-time streaming
4. Watch content appear as it's being generated

### API Endpoints

#### 1. Streaming Content Generation
**POST** `/api/v1/generate/streaming`

Generate content with real-time streaming response.

**Request Body:**
```json
{
  "query": "Generate an email campaign about Verizon 5G Business Internet",
  "document": "Focus on speed, reliability, and business benefits",
  "temperature": 0.7,
  "user_id": "user_123",
  "content_type": "email",
  "campaign_theme": "5G Business Internet",
  "target_audience": "small_business",
  "tone": "professional"
}
```

**Streaming Response:**
```
data: {"status": "processing", "session_id": "streaming_session_123", "message": "Starting content generation..."}

data: {"mime_type": "text/plain", "data": "{\"response_type\": \"complete_synthesis\"", "partial": true}

data: {"mime_type": "text/plain", "data": "{\"response_type\": \"complete_synthesis\", \"campaign_summary\": {...}}", "final": true}

data: {"mime_type": "application/json", "data": "{\"content_type\": \"email_campaign\", \"variants_count\": 2}", "summary": true}

data: {"turn_complete": true, "session_id": "streaming_session_123"}
```

#### 2. Health Check
**GET** `/api/v1/health`

Check if the API and its dependencies are healthy.

#### 3. Session Management
**GET** `/api/v1/sessions/{session_id}`

Get information about a specific session.

**GET** `/api/v1/sessions`

List all active streaming sessions.

#### 4. Server-Sent Events
**GET** `/events/{session_id}`

Establish SSE connection for real-time updates.

**POST** `/send/{session_id}`

Send message to agent via SSE.

## 🧪 Testing

### Run the Test Script
```bash
python test_streaming.py
```

This will test:
- Health check endpoint
- Streaming content generation for all content types
- Session management
- Real-time response handling

### Manual Testing with cURL
```bash
# Test streaming generation
curl -X POST "http://localhost:8000/api/v1/generate/streaming" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Generate an email campaign about Verizon 5G Business Internet",
    "content_type": "email",
    "campaign_theme": "5G Business Internet"
  }'

# Test health check
curl "http://localhost:8000/api/v1/health"

# Test session info
curl "http://localhost:8000/api/v1/sessions/streaming_session_123"
```

## 🌐 Frontend Integration

### JavaScript/TypeScript
```javascript
// Streaming content generation
const generateContent = async (payload) => {
  const response = await fetch('http://localhost:8000/api/v1/generate/streaming', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const reader = response.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value);
    const lines = chunk.split('\n');

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const data = JSON.parse(line.slice(6));
          
          if (data.mime_type === 'text/plain') {
            if (data.partial) {
              console.log('Partial:', data.data);
            } else if (data.final) {
              console.log('Final:', data.data);
            }
          }
        } catch (e) {
          console.error('Error parsing stream data:', e);
        }
      }
    }
  }
};

// Usage
generateContent({
  query: "Generate an email campaign about Verizon 5G Business Internet",
  content_type: "email",
  campaign_theme: "5G Business Internet"
});
```

### Python (Async)
```python
import aiohttp
import json

async def generate_content_streaming(payload):
    async with aiohttp.ClientSession() as session:
        async with session.post(
            'http://localhost:8000/api/v1/generate/streaming',
            json=payload
        ) as response:
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = json.loads(line[6:])
                    if data.get('mime_type') == 'text/plain':
                        print(data['data'])

# Usage
await generate_content_streaming({
    "query": "Generate an email campaign about Verizon 5G Business Internet",
    "content_type": "email"
})
```

## 📊 Response Format

The streaming API returns structured JSON content in the same format as your agents:

### Email Campaigns
```json
{
  "response_type": "complete_synthesis",
  "campaign_summary": {
    "campaign_theme": "Verizon 5G Business Internet",
    "campaign_title": "Powering Businesses with Verizon 5G Business Internet",
    "generated_variants": 2,
    "key_message": "Unlock the potential of your business...",
    "target_audience": "Small to medium-sized businesses"
  },
  "email_campaigns": [
    {
      "variant_id": 1,
      "subject_line": "Future-Proof Your Business...",
      "preview_text": "Is your business ready for what's next?",
      "email_body": "Is your business ready for what's next?...",
      "call_to_action": "Explore the possibilities",
      "cta_link": "[link to Verizon 5G Business Internet innovation page]",
      "tone": "Supportive"
    }
  ]
}
```

### Social Media Posts
```json
{
  "response_type": "complete_synthesis",
  "social_media_posts": [
    {
      "variant_id": 1,
      "platform": "Facebook",
      "post_content": "Is your business ready for the future? 🚀...",
      "hashtags": ["#Verizon5GBusiness", "#Innovation", "#5G"],
      "character_count": 210,
      "engagement_type": "Supportive"
    }
  ]
}
```

### Long-form Content
```json
{
  "response_type": "complete_synthesis",
  "long_form_content": [
    {
      "variant_id": 1,
      "content_type": "blog post",
      "title": "Is Your Business Ready for the Future?...",
      "introduction": "The business landscape is constantly evolving...",
      "main_content": "Verizon 5G Business Internet enables innovation...",
      "conclusion": "Invest in the future of your business...",
      "key_points": ["Enables innovation with cutting-edge technology", ...],
      "word_count": 150,
      "reading_time": "1 minute",
      "tone": "Supportive"
    }
  ],
  "metadata": {
    "campaign_id": "5g-business-internet-002",
    "generated_at": "2024-01-15T11:15:00Z",
    "version": "1.0"
  }
}
```

## 🔧 Configuration

### Environment Variables
| Variable | Default | Description |
|----------|---------|-------------|
| `GOOGLE_API_KEY` | Required | Your Gemini API key |
| `REDIS_URL` | `redis://localhost:6379` | Redis connection URL |
| `SESSION_TTL` | `3600` | Session timeout in seconds |

### Server Configuration
- **Host**: 0.0.0.0 (all interfaces)
- **Port**: 8000
- **CORS**: Enabled for all origins (configure for production)
- **Logging**: INFO level

## 🚀 Production Deployment

### Docker Deployment
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Environment Setup
```bash
# Production environment variables
GOOGLE_API_KEY=your_production_api_key
REDIS_URL=redis://your-redis-server:6379
SESSION_TTL=7200
```

### Load Balancing
For production, consider:
- **Nginx**: Reverse proxy with SSE support
- **Redis Cluster**: For session storage
- **Multiple Instances**: Load balancing across servers
- **SSL/TLS**: HTTPS for secure connections

## 📈 Monitoring

### Health Monitoring
- **Health Check**: `/api/v1/health`
- **Session Monitoring**: `/api/v1/sessions`
- **Redis Connection**: Automatic health checks

### Logging
- **Request Logging**: All API requests logged
- **Error Logging**: Detailed error information
- **Performance Metrics**: Processing time tracking

## 🔒 Security

### Production Security
- **CORS Configuration**: Restrict origins
- **Rate Limiting**: Implement request limits
- **Authentication**: Add JWT or API key auth
- **Input Validation**: Validate all inputs
- **HTTPS**: Use SSL/TLS encryption

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For issues and questions:
1. Check the documentation
2. Review the test examples
3. Check the health endpoint
4. Verify Redis connection
5. Check API key configuration 