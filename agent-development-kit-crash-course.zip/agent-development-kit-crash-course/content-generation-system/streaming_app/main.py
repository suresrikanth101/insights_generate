#!/usr/bin/env python3
"""
FastAPI Streaming Server for Multi-Agent Content Generation System
Based on ADK Streaming documentation with real-time capabilities.
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

# Import the content generation system
from content_manager_agent.agent import root_agent
from redis_session_service import RedisSessionService
from google.adk.runners import Runner
from google.adk import types
import config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="VBG Content Generation Streaming API",
    description="Real-time streaming API for B2B marketing content generation using multi-agent system",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Initialize Redis session service
session_service = RedisSessionService(
    redis_url=config.REDIS_URL,
    default_ttl=config.SESSION_TTL
)

# Initialize agent runner
runner = Runner(
    agent=root_agent,
    app_name="VBG Content Generation Streaming",
    session_service=session_service,
)

# In-memory session storage for streaming
active_sessions: Dict[str, Dict[str, Any]] = {}

# Pydantic models
class MessageRequest(BaseModel):
    """Message request model for streaming."""
    mime_type: str
    data: str
    user_id: Optional[str] = "streaming_user"

class ContentGenerationRequest(BaseModel):
    """Content generation request model."""
    query: str
    document: Optional[str] = None
    temperature: Optional[float] = 0.7
    user_id: Optional[str] = "streaming_user"
    content_type: Optional[str] = None
    campaign_theme: Optional[str] = None
    target_audience: Optional[str] = "business"
    tone: Optional[str] = "professional"

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main HTML page."""
    with open("static/index.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.get("/api/v1/health")
async def health_check():
    """Health check endpoint."""
    try:
        session_service.redis_client.ping()
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "services": {
                "redis": "connected",
                "agent": "ready",
                "streaming": "active"
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail=f"Service unhealthy: {str(e)}")

@app.post("/api/v1/generate/streaming")
async def generate_content_streaming(request: ContentGenerationRequest):
    """
    Generate content with real-time streaming response.
    Returns a streaming response with partial updates.
    """
    
    async def generate_stream():
        session_id = f"streaming_session_{request.user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        try:
            # Create or get session
            session = session_service.get_session(
                app_name="VBG Content Generation Streaming",
                user_id=request.user_id,
                session_id=session_id
            )
            
            if not session:
                # Create new session
                initial_state = {
                    "user_name": f"Streaming User {request.user_id}",
                    "content_history": [],
                    "preferences": {
                        "content_types": ["email", "social", "long_form"],
                        "tone": request.tone,
                        "target_audience": request.target_audience,
                        "verizon_focus": ["5G Business Internet", "Cloud Security", "Digital Transformation"]
                    },
                    "interaction_history": [],
                    "generated_content": "",
                    "metadata": {},
                    "content_stats": {
                        "total_generated": 0,
                        "email_campaigns": 0,
                        "social_posts": 0,
                        "long_form_content": 0
                    }
                }
                
                session = session_service.create_session(
                    app_name="VBG Content Generation Streaming",
                    user_id=request.user_id,
                    session_id=session_id,
                    state=initial_state
                )
            
            # Build enhanced query
            enhanced_query = request.query
            if request.document:
                enhanced_query = f"Context: {request.document}\n\nRequest: {request.query}"
            if request.content_type:
                enhanced_query = f"{enhanced_query}\n\nPreferred content type: {request.content_type}"
            if request.campaign_theme:
                enhanced_query = f"{enhanced_query}\n\nCampaign theme: {request.campaign_theme}"
            
            # Create content for agent
            content = types.Content(role="user", parts=[types.Part(text=enhanced_query)])
            
            # Send initial status
            yield f"data: {json.dumps({'status': 'processing', 'session_id': session_id, 'message': 'Starting content generation...'})}\n\n"
            
            # Process with streaming
            final_response = ""
            agent_name = None
            
            async for event in runner.run_async(
                user_id=request.user_id,
                session_id=session_id,
                new_message=content
            ):
                if event.author:
                    agent_name = event.author
                
                # Send partial updates
                if event.content and event.content.parts:
                    for part in event.content.parts:
                        if hasattr(part, "text") and part.text:
                            text_chunk = part.text.strip()
                            if text_chunk:
                                final_response += text_chunk
                                
                                # Send partial text update
                                yield f"data: {json.dumps({'mime_type': 'text/plain', 'data': text_chunk, 'partial': True})}\n\n"
                
                # Check if this is the final response
                if event.is_final_response():
                    if event.content and event.content.parts and hasattr(event.content.parts[0], "text"):
                        final_text = event.content.parts[0].text.strip()
                        if final_text and final_text != final_response:
                            # Send the complete final response
                            yield f"data: {json.dumps({'mime_type': 'text/plain', 'data': final_text, 'final': True})}\n\n"
                            final_response = final_text
            
            # Parse and send structured content summary
            try:
                import json as json_parser
                parsed_content = json_parser.loads(final_response)
                
                # Determine content type
                content_type = "unknown"
                if "email_campaigns" in parsed_content:
                    content_type = "email_campaign"
                elif "social_media_posts" in parsed_content:
                    content_type = "social_media"
                elif "long_form_content" in parsed_content:
                    content_type = "long_form"
                
                # Send content summary
                summary_data = {
                    "content_type": content_type,
                    "session_id": session_id,
                    "agent_name": agent_name,
                    "summary": parsed_content.get("campaign_summary", {}),
                    "variants_count": len(parsed_content.get("email_campaigns", []) or 
                                        parsed_content.get("social_media_posts", []) or 
                                        parsed_content.get("long_form_content", [])),
                    "final": True
                }
                
                yield f"data: {json.dumps({'mime_type': 'application/json', 'data': json.dumps(summary_data), 'summary': True})}\n\n"
                
                # Update session state
                updated_state = session.state.copy()
                updated_state["generated_content"] = final_response
                updated_state["last_content_type"] = content_type
                updated_state["last_request"] = {
                    "query": request.query,
                    "timestamp": datetime.now().isoformat(),
                    "content_type": content_type
                }
                
                # Update content statistics
                content_stats = updated_state.get("content_stats", {})
                content_stats["total_generated"] += 1
                if content_type == "email_campaign":
                    content_stats["email_campaigns"] += 1
                elif content_type == "social_media":
                    content_stats["social_posts"] += 1
                elif content_type == "long_form":
                    content_stats["long_form_content"] += 1
                updated_state["content_stats"] = content_stats
                
                session_service.update_session(
                    app_name="VBG Content Generation Streaming",
                    user_id=request.user_id,
                    session_id=session_id,
                    state=updated_state
                )
                
            except json_parser.JSONDecodeError:
                # If not JSON, send as plain text
                yield f"data: {json.dumps({'mime_type': 'text/plain', 'data': final_response, 'final': True, 'raw': True})}\n\n"
            
            # Send completion signal
            yield f"data: {json.dumps({'turn_complete': True, 'session_id': session_id})}\n\n"
            
        except Exception as e:
            logger.error(f"Error in streaming generation: {e}")
            yield f"data: {json.dumps({'error': str(e), 'session_id': session_id})}\n\n"
            yield f"data: {json.dumps({'turn_complete': True, 'session_id': session_id})}\n\n"
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Content-Type": "text/event-stream",
        }
    )

@app.get("/events/{session_id}")
async def stream_events(session_id: str, is_audio: bool = False):
    """
    Server-Sent Events endpoint for real-time streaming.
    Based on ADK streaming documentation.
    """
    
    async def event_stream():
        try:
            # Store session info
            active_sessions[session_id] = {
                "created_at": datetime.now(),
                "is_audio": is_audio,
                "messages": []
            }
            
            # Send connection established
            yield f"data: {json.dumps({'status': 'connected', 'session_id': session_id, 'is_audio': is_audio})}\n\n"
            
            # Keep connection alive
            while True:
                await asyncio.sleep(1)
                # Send heartbeat
                yield f"data: {json.dumps({'heartbeat': datetime.now().isoformat()})}\n\n"
                
        except Exception as e:
            logger.error(f"Error in event stream: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        finally:
            # Clean up session
            if session_id in active_sessions:
                del active_sessions[session_id]
    
    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Content-Type": "text/event-stream",
        }
    )

@app.post("/send/{session_id}")
async def send_message(session_id: str, message: MessageRequest):
    """
    Send message to agent and get streaming response.
    Based on ADK streaming documentation.
    """
    
    if session_id not in active_sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    
    try:
        # Store message in session
        active_sessions[session_id]["messages"].append({
            "timestamp": datetime.now().isoformat(),
            "mime_type": message.mime_type,
            "data": message.data
        })
        
        # Process text message
        if message.mime_type == "text/plain":
            # Create content for agent
            content = types.Content(role="user", parts=[types.Part(text=message.data)])
            
            # Process with agent
            final_response = ""
            
            async for event in runner.run_async(
                user_id=message.user_id,
                session_id=session_id,
                new_message=content
            ):
                if event.content and event.content.parts:
                    for part in event.content.parts:
                        if hasattr(part, "text") and part.text:
                            text_chunk = part.text.strip()
                            if text_chunk:
                                final_response += text_chunk
                
                if event.is_final_response():
                    break
            
            return {
                "success": True,
                "session_id": session_id,
                "response": final_response,
                "timestamp": datetime.now().isoformat()
            }
        
        return {
            "success": True,
            "session_id": session_id,
            "message": "Message received",
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error processing message: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/sessions/{session_id}")
async def get_session_info(session_id: str, user_id: str = "streaming_user"):
    """Get session information."""
    try:
        session = session_service.get_session(
            app_name="VBG Content Generation Streaming",
            user_id=user_id,
            session_id=session_id
        )
        
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return {
            "session_id": session_id,
            "user_id": user_id,
            "created_at": session.created_at.isoformat(),
            "last_accessed": session.last_accessed.isoformat(),
            "state": session.state,
            "active_session": session_id in active_sessions
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting session info: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/sessions")
async def list_active_sessions():
    """List all active streaming sessions."""
    return {
        "active_sessions": len(active_sessions),
        "sessions": [
            {
                "session_id": session_id,
                "created_at": session_data["created_at"].isoformat(),
                "is_audio": session_data["is_audio"],
                "message_count": len(session_data["messages"])
            }
            for session_id, session_data in active_sessions.items()
        ]
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 