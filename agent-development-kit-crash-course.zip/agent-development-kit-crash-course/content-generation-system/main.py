"""
Main Application for Verizon Business Group Content Generation System.
"""

import asyncio
import logging
from datetime import datetime

# Import the main content manager agent
from content_manager_agent.agent import content_manager_agent
from dotenv import load_dotenv
from google.adk.runners import Runner
from redis_session_service import RedisSessionService
import config

# Import utilities
from utils import add_user_query_to_history, call_agent_async, display_state

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ===== PART 1: Initialize Redis Session Service =====
session_service = RedisSessionService(
    redis_url=config.REDIS_URL,
    default_ttl=config.SESSION_TTL
)

# ===== PART 2: Define Initial State =====
initial_state = {
    "user_name": "VBG Marketing User",
    "content_history": [],
    "preferences": {
        "content_types": ["email", "social", "long_form"],
        "tone": "professional",
        "target_audience": "business"
    },
    "interaction_history": [],
    "generated_content": "",
    "metadata": {}
}

async def main_async():
    """Main async function for the VBG content generation system."""
    
    APP_NAME = "VBG Content Generation System"
    USER_ID = "vbg_user_001"

    try:
        # ===== PART 3: Session Creation =====
        new_session = session_service.create_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            state=initial_state,
        )
        SESSION_ID = new_session.id
        print(f"✅ Created new session: {SESSION_ID}")
        print(f"🔗 Redis URL: {config.REDIS_URL}")

        # ===== PART 4: Agent Runner Setup =====
        runner = Runner(
            agent=content_manager_agent,
            app_name=APP_NAME,
            session_service=session_service,
        )

        # ===== PART 5: Interactive Conversation Loop =====
        print("\n🚀 Welcome to the Verizon Business Group Content Generation System!")
        print("=" * 60)
        print("This system can generate:")
        print("  📧 Professional B2B emails")
        print("  🌐 Engaging B2B social media posts")
        print("  📝 Comprehensive long-form business content")
        print("\nType 'exit' or 'quit' to end the conversation.")
        print("Type 'help' for usage examples.")
        print("Type 'state' to view current session state.")
        print("=" * 60)

        while True:
            user_input = input("\n💬 You: ")

            if user_input.lower() in ["exit", "quit"]:
                print("👋 Ending conversation. Goodbye!")
                break

            if user_input.lower() == "help":
                print("\n📚 Usage Examples:")
                print("  • 'Generate a professional email to follow up with a client about a new network solution'")
                print("  • 'Create a LinkedIn post about digital transformation in B2B'")
                print("  • 'Write a long-form article on cloud security for enterprises'")
                print("  • 'Generate an email template for a B2B product launch'")
                continue

            if user_input.lower() == "state":
                display_state(session_service, APP_NAME, USER_ID, SESSION_ID, "Current Session State")
                continue

            add_user_query_to_history(
                session_service, APP_NAME, USER_ID, SESSION_ID, user_input
            )

            current_session = session_service.get_session(APP_NAME, USER_ID, SESSION_ID)
            if current_session:
                updated_state = current_session.state.copy()
                updated_state["user_query"] = user_input
                session_service.update_session(APP_NAME, USER_ID, SESSION_ID, updated_state)

            print(f"\n🤖 Processing: {user_input}")
            await call_agent_async(runner, USER_ID, SESSION_ID, user_input)

            final_session = session_service.get_session(APP_NAME, USER_ID, SESSION_ID)
            if final_session and final_session.state.get("generated_content"):
                print("\n" + "=" * 60)
                print("📄 GENERATED CONTENT:")
                print("=" * 60)
                print(final_session.state["generated_content"])
                print("=" * 60)
                
                metadata = final_session.state.get("metadata", {})
                if metadata:
                    print(f"\n📊 Content Type: {metadata.get('content_type', 'Unknown')}")
                    print(f"📝 Word Count: {metadata.get('word_count', 0)}")
                    print(f"🔤 Character Count: {metadata.get('character_count', 0)}")

    except Exception as e:
        logger.error(f"Error in main application: {e}")
        print(f"❌ Error: {e}")
        print("Please check your configuration and Redis connection.")

    finally:
        try:
            final_session = session_service.get_session(APP_NAME, USER_ID, SESSION_ID)
            if final_session:
                print("\n📊 Final Session State:")
                print(f"  Session ID: {final_session.id}")
                print(f"  Created: {final_session.created_at}")
                print(f"  Last Accessed: {final_session.last_accessed}")
                print(f"  Content Generated: {len(final_session.state.get('generated_content', ''))} characters")
        except Exception as e:
            logger.error(f"Error displaying final state: {e}")

def main():
    try:
        if not config.GOOGLE_API_KEY:
            raise ValueError("GOOGLE_API_KEY environment variable is required")
        print("✅ Configuration validated successfully")
        asyncio.run(main_async())
    except ValueError as e:
        print(f"❌ Configuration error: {e}")
        print("Please check your environment variables:")
        print("  - GOOGLE_API_KEY: Your Gemini API key")
        print("  - REDIS_URL: Redis connection URL (default: redis://localhost:6379)")
    except Exception as e:
        logger.error(f"Application error: {e}")
        print(f"❌ Application error: {e}")

if __name__ == "__main__":
    main() 