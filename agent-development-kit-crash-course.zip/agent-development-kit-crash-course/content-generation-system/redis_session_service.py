"""
Redis Session Service for Content Generation System
Uses Redis native features for efficient session management.
"""

import redis
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from google.adk.sessions import Session, SessionService
import config

class RedisSessionService(SessionService):
    """
    Redis-based session service using native Redis data structures.
    Implements the ADK SessionService interface.
    """
    
    def __init__(self, redis_url: str = None, default_ttl: int = None):
        """
        Initialize Redis session service.
        
        Args:
            redis_url: Redis connection URL
            default_ttl: Default session TTL in seconds
        """
        self.redis_url = redis_url or config.REDIS_URL
        self.default_ttl = default_ttl or config.SESSION_TTL
        self.logger = logging.getLogger(__name__)
        
        # Initialize Redis connection
        self.redis_client = redis.from_url(
            self.redis_url,
            decode_responses=True,
            retry_on_timeout=True,
            max_connections=10
        )
        
        # Test connection
        try:
            self.redis_client.ping()
            self.logger.info("Connected to Redis successfully")
        except Exception as e:
            self.logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    def create_session(
        self, 
        app_name: str, 
        user_id: str, 
        session_id: str = None, 
        state: Dict[str, Any] = None
    ) -> Session:
        """
        Create a new session using Redis Hash.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier (auto-generated if None)
            state: Initial session state
            
        Returns:
            Session object
        """
        try:
            # Generate session ID if not provided
            if session_id is None:
                session_id = f"{app_name}_{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # Prepare session data
            session_data = {
                "app_name": app_name,
                "user_id": user_id,
                "session_id": session_id,
                "created_at": datetime.now().isoformat(),
                "last_accessed": datetime.now().isoformat(),
                "state": json.dumps(state or {})
            }
            
            # Store session data in Redis Hash
            session_key = f"session:{session_id}"
            self.redis_client.hset(session_key, mapping=session_data)
            
            # Set TTL for automatic expiration
            self.redis_client.expire(session_key, self.default_ttl)
            
            # Add session to user's session list
            user_sessions_key = f"user_sessions:{user_id}"
            self.redis_client.sadd(user_sessions_key, session_id)
            
            # Add session to app's session list
            app_sessions_key = f"app_sessions:{app_name}"
            self.redis_client.sadd(app_sessions_key, session_id)
            
            self.logger.info(f"Created session {session_id} for user {user_id} in app {app_name}")
            
            return Session(
                id=session_id,
                state=state or {},
                created_at=datetime.now(),
                last_accessed=datetime.now()
            )
            
        except Exception as e:
            self.logger.error(f"Failed to create session {session_id}: {e}")
            raise
    
    def get_session(self, app_name: str, user_id: str, session_id: str) -> Optional[Session]:
        """
        Retrieve session data using Redis Hash.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier
            
        Returns:
            Session object or None if not found
        """
        try:
            session_key = f"session:{session_id}"
            
            # Get all session data from Redis Hash
            session_data = self.redis_client.hgetall(session_key)
            
            if not session_data:
                return None
            
            # Update last accessed time
            self.redis_client.hset(session_key, "last_accessed", datetime.now().isoformat())
            
            # Refresh TTL
            self.redis_client.expire(session_key, self.default_ttl)
            
            # Parse state from JSON
            state = json.loads(session_data.get("state", "{}"))
            
            # Parse timestamps
            created_at = datetime.fromisoformat(session_data.get("created_at", datetime.now().isoformat()))
            last_accessed = datetime.fromisoformat(session_data.get("last_accessed", datetime.now().isoformat()))
            
            return Session(
                id=session_id,
                state=state,
                created_at=created_at,
                last_accessed=last_accessed
            )
            
        except Exception as e:
            self.logger.error(f"Failed to get session {session_id}: {e}")
            return None
    
    def update_session(self, app_name: str, user_id: str, session_id: str, state: Dict[str, Any]) -> bool:
        """
        Update session state using Redis Hash.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier
            state: New session state
            
        Returns:
            bool: True if updated successfully
        """
        try:
            session_key = f"session:{session_id}"
            
            # Update session state in Redis Hash
            self.redis_client.hset(session_key, "state", json.dumps(state))
            self.redis_client.hset(session_key, "last_accessed", datetime.now().isoformat())
            
            # Refresh TTL
            self.redis_client.expire(session_key, self.default_ttl)
            
            self.logger.info(f"Updated session {session_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to update session {session_id}: {e}")
            return False
    
    def delete_session(self, app_name: str, user_id: str, session_id: str) -> bool:
        """
        Delete session using Redis DEL.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier
            
        Returns:
            bool: True if deleted successfully
        """
        try:
            session_key = f"session:{session_id}"
            
            # Delete session
            self.redis_client.delete(session_key)
            
            # Remove from user's session list
            user_sessions_key = f"user_sessions:{user_id}"
            self.redis_client.srem(user_sessions_key, session_id)
            
            # Remove from app's session list
            app_sessions_key = f"app_sessions:{app_name}"
            self.redis_client.srem(app_sessions_key, session_id)
            
            self.logger.info(f"Deleted session {session_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete session {session_id}: {e}")
            return False
    
    def get_user_sessions(self, user_id: str) -> List[str]:
        """
        Get all sessions for a user using Redis Set.
        
        Args:
            user_id: User identifier
            
        Returns:
            List of session IDs
        """
        try:
            user_sessions_key = f"user_sessions:{user_id}"
            sessions = self.redis_client.smembers(user_sessions_key)
            return list(sessions)
            
        except Exception as e:
            self.logger.error(f"Failed to get sessions for user {user_id}: {e}")
            return []
    
    def get_app_sessions(self, app_name: str) -> List[str]:
        """
        Get all sessions for an app using Redis Set.
        
        Args:
            app_name: Application name
            
        Returns:
            List of session IDs
        """
        try:
            app_sessions_key = f"app_sessions:{app_name}"
            sessions = self.redis_client.smembers(app_sessions_key)
            return list(sessions)
            
        except Exception as e:
            self.logger.error(f"Failed to get sessions for app {app_name}: {e}")
            return []
    
    def session_exists(self, app_name: str, user_id: str, session_id: str) -> bool:
        """
        Check if session exists using Redis EXISTS.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier
            
        Returns:
            bool: True if session exists
        """
        try:
            session_key = f"session:{session_id}"
            return bool(self.redis_client.exists(session_key))
            
        except Exception as e:
            self.logger.error(f"Failed to check session {session_id}: {e}")
            return False
    
    def get_session_ttl(self, session_id: str) -> int:
        """
        Get remaining TTL for session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            int: Remaining TTL in seconds, -1 if no TTL, -2 if key doesn't exist
        """
        try:
            session_key = f"session:{session_id}"
            return self.redis_client.ttl(session_key)
            
        except Exception as e:
            self.logger.error(f"Failed to get TTL for session {session_id}: {e}")
            return -2
    
    def extend_session(self, session_id: str, ttl_seconds: int = None) -> bool:
        """
        Extend session TTL.
        
        Args:
            session_id: Session identifier
            ttl_seconds: New TTL in seconds (uses default if None)
            
        Returns:
            bool: True if extended successfully
        """
        try:
            session_key = f"session:{session_id}"
            ttl = ttl_seconds or self.default_ttl
            
            return bool(self.redis_client.expire(session_key, ttl))
            
        except Exception as e:
            self.logger.error(f"Failed to extend session {session_id}: {e}")
            return False
    
    def get_redis_stats(self) -> Dict[str, Any]:
        """
        Get Redis statistics for monitoring.
        
        Returns:
            Dict containing Redis stats
        """
        try:
            info = self.redis_client.info()
            return {
                "connected_clients": info.get("connected_clients", 0),
                "used_memory_human": info.get("used_memory_human", "0B"),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0),
                "total_sessions": len(self.redis_client.keys("session:*")),
                "total_users": len(self.redis_client.keys("user_sessions:*")),
                "total_apps": len(self.redis_client.keys("app_sessions:*"))
            }
        except Exception as e:
            self.logger.error(f"Failed to get Redis stats: {e}")
            return {}
    
    def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions (Redis handles this automatically with TTL).
        
        Returns:
            int: Number of sessions cleaned up
        """
        try:
            # Redis automatically removes expired keys
            # This method is for manual cleanup if needed
            expired_keys = self.redis_client.keys("session:*")
            cleaned_count = 0
            
            for key in expired_keys:
                if self.redis_client.ttl(key) == -2:  # Key doesn't exist
                    self.redis_client.delete(key)
                    cleaned_count += 1
            
            self.logger.info(f"Cleaned up {cleaned_count} expired sessions")
            return cleaned_count
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup expired sessions: {e}")
            return 0 