"""
Tools for the Content Manager Agent.
"""

from google.adk import Tool

# Create the get_current_time tool instance
get_current_time = Tool(
    name="get_current_time",
    description="Get the current date and time",
    parameters={
        "type": "object",
        "properties": {},
        "required": []
    }
) 