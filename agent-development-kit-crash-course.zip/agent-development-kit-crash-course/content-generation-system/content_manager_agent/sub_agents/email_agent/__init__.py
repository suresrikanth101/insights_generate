"""
Email Agent Package.
"""

from .agent import email_agent

__all__ = ["email_agent"] 