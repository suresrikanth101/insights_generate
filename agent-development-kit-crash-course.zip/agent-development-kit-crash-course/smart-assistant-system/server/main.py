from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import uvicorn
from google.adk.sessions import InMemorySessionService

from agents.root_agent import smart_assistant

# Initialize FastAPI app
app = FastAPI(
    title="Smart Assistant System API",
    description="A multi-agent system for research, writing, and analysis tasks",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize session service
session_service = InMemorySessionService()

# Pydantic models for request/response
class ChatRequest(BaseModel):
    message: str
    session_id: str

class ChatResponse(BaseModel):
    response: str
    session_id: str
    timestamp: str

class ResearchRequest(BaseModel):
    topic: str
    depth: str = "comprehensive"
    session_id: str

class ResearchResponse(BaseModel):
    results: Dict[str, Any]
    session_id: str
    timestamp: str

class WritingRequest(BaseModel):
    content_type: str
    topic: str
    length: str = "medium"
    tone: str = "professional"
    session_id: str

class WritingResponse(BaseModel):
    content: Dict[str, Any]
    session_id: str
    timestamp: str

class AnalysisRequest(BaseModel):
    data: str
    analysis_type: str = "general"
    session_id: str

class AnalysisResponse(BaseModel):
    analysis: Dict[str, Any]
    session_id: str
    timestamp: str

class SessionInfo(BaseModel):
    session_id: str
    message_count: int
    created_at: str
    last_activity: str

# API Endpoints
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Smart Assistant System",
        "version": "1.0.0",
        "agents": ["research_agent", "writing_agent", "analysis_agent"]
    }

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Send a message to the smart assistant"""
    try:
        # Get or create session
        session = session_service.get_or_create_session(request.session_id)
        
        # Process message through the smart assistant
        response = await smart_assistant.run(
            request.message,
            session=session
        )
        
        return ChatResponse(
            response=response.content,
            session_id=request.session_id,
            timestamp=response.timestamp.isoformat() if response.timestamp else ""
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chat: {str(e)}")

@app.post("/research", response_model=ResearchResponse)
async def research(request: ResearchRequest):
    """Request research on a specific topic"""
    try:
        session = session_service.get_or_create_session(request.session_id)
        
        # Delegate to research agent
        research_message = f"Please research {request.topic} with {request.depth} depth"
        response = await smart_assistant.run(
            research_message,
            session=session
        )
        
        return ResearchResponse(
            results={"research": response.content, "topic": request.topic},
            session_id=request.session_id,
            timestamp=response.timestamp.isoformat() if response.timestamp else ""
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing research: {str(e)}")

@app.post("/write", response_model=WritingResponse)
async def write_content(request: WritingRequest):
    """Generate content based on requirements"""
    try:
        session = session_service.get_or_create_session(request.session_id)
        
        # Delegate to writing agent
        writing_message = f"Please create a {request.length} {request.content_type} about {request.topic} in a {request.tone} tone"
        response = await smart_assistant.run(
            writing_message,
            session=session
        )
        
        return WritingResponse(
            content={"generated_content": response.content, "parameters": request.dict()},
            session_id=request.session_id,
            timestamp=response.timestamp.isoformat() if response.timestamp else ""
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating content: {str(e)}")

@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_data(request: AnalysisRequest):
    """Analyze data or information"""
    try:
        session = session_service.get_or_create_session(request.session_id)
        
        # Delegate to analysis agent
        analysis_message = f"Please analyze this data with {request.analysis_type} analysis: {request.data}"
        response = await smart_assistant.run(
            analysis_message,
            session=session
        )
        
        return AnalysisResponse(
            analysis={"analysis_results": response.content, "data": request.data},
            session_id=request.session_id,
            timestamp=response.timestamp.isoformat() if response.timestamp else ""
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error analyzing data: {str(e)}")

@app.get("/sessions/{session_id}", response_model=SessionInfo)
async def get_session_info(session_id: str):
    """Get information about a specific session"""
    try:
        session = session_service.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        return SessionInfo(
            session_id=session_id,
            message_count=len(session.messages) if session.messages else 0,
            created_at=session.created_at.isoformat() if session.created_at else "",
            last_activity=session.last_activity.isoformat() if session.last_activity else ""
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving session: {str(e)}")

@app.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    """Delete a specific session"""
    try:
        session_service.delete_session(session_id)
        return {"message": f"Session {session_id} deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting session: {str(e)}")

@app.get("/agents")
async def list_agents():
    """List all available agents and their capabilities"""
    return {
        "root_agent": {
            "name": "smart_assistant",
            "description": "Coordinates and delegates tasks to specialized sub-agents",
            "capabilities": ["Task delegation", "Coordination", "Synthesis"]
        },
        "sub_agents": {
            "research_agent": {
                "description": "Web research, trend analysis, and information gathering",
                "tools": ["search_web", "analyze_trends", "gather_statistics"]
            },
            "writing_agent": {
                "description": "Content creation and writing tasks",
                "tools": ["generate_content", "edit_content", "create_outline"]
            },
            "analysis_agent": {
                "description": "Data analysis and insights generation",
                "tools": ["analyze_data", "generate_report", "compare_metrics", "forecast_trends"]
            }
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000) 