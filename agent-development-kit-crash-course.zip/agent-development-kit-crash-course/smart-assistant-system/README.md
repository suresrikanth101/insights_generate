# Smart Assistant System

A multi-agent system built with Google ADK that provides intelligent assistance through specialized sub-agents.

## Architecture

- **Root Agent**: `smart_assistant` - Coordinates and delegates tasks to specialized sub-agents
- **Sub-Agents**:
  - `research_agent` - Performs web research and information gathering
  - `writing_agent` - Handles content creation and writing tasks
  - `analysis_agent` - Provides data analysis and insights

## Features

- **Multi-Agent Coordination**: Root agent intelligently delegates tasks to appropriate sub-agents
- **Specialized Tools**: Each sub-agent has domain-specific tools and capabilities
- **Session Management**: Built-in session handling for conversation continuity
- **REST API**: FastAPI-based API for easy integration
- **Structured Outputs**: JSON-based responses with clear structure

## Quick Start

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Start the API Server**:
   ```bash
   python server/main.py
   ```

3. **Test the System**:
   ```bash
   python test_system.py
   ```

## API Endpoints

- `POST /chat` - Send messages to the smart assistant
- `POST /research` - Request research on a specific topic
- `POST /write` - Generate content based on requirements
- `POST /analyze` - Analyze data or information
- `GET /health` - Health check endpoint
- `GET /sessions/{session_id}` - Get session information
- `DELETE /sessions/{session_id}` - Delete a session

## Usage Examples

### Basic Chat
```bash
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Can you help me research the latest AI trends?",
    "session_id": "user123"
  }'
```

### Research Request
```bash
curl -X POST "http://localhost:8000/research" \
  -H "Content-Type: application/json" \
  -d '{
    "topic": "quantum computing applications",
    "depth": "comprehensive",
    "session_id": "user123"
  }'
```

### Content Generation
```bash
curl -X POST "http://localhost:8000/write" \
  -H "Content-Type: application/json" \
  -d '{
    "content_type": "blog_post",
    "topic": "Machine Learning Basics",
    "length": "medium",
    "session_id": "user123"
  }'
```

## Project Structure

```
smart-assistant-system/
├── README.md
├── requirements.txt
├── server/
│   └── main.py
├── agents/
│   ├── __init__.py
│   ├── root_agent.py
│   └── sub_agents/
│       ├── __init__.py
│       ├── research_agent.py
│       ├── writing_agent.py
│       └── analysis_agent.py
└── test_system.py
```

## Configuration

The system uses Google ADK with Gemini 2.0 Flash model by default. You can modify the model in each agent's configuration if needed.

## Session Management

Sessions are managed using ADK's built-in InMemorySessionService, providing conversation continuity and context preservation across multiple interactions. 