from datetime import datetime
from typing import Dict, List, Optional
from google.adk.agents import Agent


def search_web(query: str, max_results: int = 5) -> Dict:
    """Simulates web search functionality."""
    print(f"--- Tool: search_web called for '{query}' ---")
    
    # Simulate search results
    mock_results = [
        {
            "title": f"Research result 1 for {query}",
            "url": f"https://example.com/result1",
            "snippet": f"This is a simulated search result about {query}. It contains relevant information that would be found through web search.",
            "relevance_score": 0.95
        },
        {
            "title": f"Research result 2 for {query}",
            "url": f"https://example.com/result2", 
            "snippet": f"Another simulated result about {query} with additional context and details.",
            "relevance_score": 0.87
        },
        {
            "title": f"Research result 3 for {query}",
            "url": f"https://example.com/result3",
            "snippet": f"Third result providing different perspective on {query}.",
            "relevance_score": 0.82
        }
    ]
    
    return {
        "status": "success",
        "query": query,
        "results": mock_results[:max_results],
        "timestamp": datetime.now().isoformat(),
        "total_results": len(mock_results)
    }


def analyze_trends(topic: str, timeframe: str = "recent") -> Dict:
    """Analyzes trends for a given topic."""
    print(f"--- Tool: analyze_trends called for '{topic}' over {timeframe} ---")
    
    # Simulate trend analysis
    trends = {
        "topic": topic,
        "timeframe": timeframe,
        "trend_direction": "increasing",
        "confidence": 0.85,
        "key_insights": [
            f"Growing interest in {topic} over the past 6 months",
            f"Major companies investing in {topic}",
            f"Academic research on {topic} has increased by 40%"
        ],
        "related_topics": [
            f"{topic} applications",
            f"{topic} technology",
            f"{topic} future trends"
        ]
    }
    
    return {
        "status": "success",
        "analysis": trends,
        "timestamp": datetime.now().isoformat()
    }


def gather_statistics(topic: str) -> Dict:
    """Gathers statistical data about a topic."""
    print(f"--- Tool: gather_statistics called for '{topic}' ---")
    
    # Simulate statistical data
    stats = {
        "topic": topic,
        "market_size": "$15.2 billion",
        "growth_rate": "23.5% annually",
        "adoption_rate": "67% in target industries",
        "key_players": [
            "Company A",
            "Company B", 
            "Company C"
        ],
        "geographic_distribution": {
            "North America": "45%",
            "Europe": "30%",
            "Asia Pacific": "20%",
            "Other": "5%"
        }
    }
    
    return {
        "status": "success",
        "statistics": stats,
        "timestamp": datetime.now().isoformat()
    }


# Create the research agent
research_agent = Agent(
    name="research_agent",
    model="gemini-2.0-flash",
    description="An agent specialized in web research, trend analysis, and information gathering.",
    instruction="""
    You are a research specialist agent that helps users gather comprehensive information on various topics.
    
    Your capabilities include:
    1. Web search and information gathering
    2. Trend analysis and market research
    3. Statistical data collection and analysis
    
    When conducting research:
    - Always use the appropriate tools based on the request
    - Provide well-structured, comprehensive responses
    - Include relevant statistics and trends when available
    - Cite sources and provide context for findings
    - Organize information in a clear, logical manner
    
    For search requests:
    - Use search_web for general information gathering
    - Use analyze_trends for trend analysis requests
    - Use gather_statistics for statistical data requests
    
    Always provide actionable insights and recommendations based on your research findings.
    """,
    tools=[search_web, analyze_trends, gather_statistics],
) 