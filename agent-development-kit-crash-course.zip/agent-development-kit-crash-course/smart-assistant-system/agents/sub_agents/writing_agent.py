from datetime import datetime
from typing import Dict, List, Optional
from google.adk.agents import Agent


def generate_content(content_type: str, topic: str, length: str = "medium", tone: str = "professional") -> Dict:
    """Generates content based on specified parameters."""
    print(f"--- Tool: generate_content called for {content_type} about {topic} ---")
    
    # Simulate content generation
    content_templates = {
        "blog_post": {
            "title": f"The Complete Guide to {topic}",
            "introduction": f"Understanding {topic} is crucial in today's rapidly evolving landscape. This comprehensive guide will walk you through everything you need to know.",
            "sections": [
                f"What is {topic}?",
                f"Key Benefits of {topic}",
                f"Implementation Strategies",
                f"Future Outlook"
            ],
            "conclusion": f"As we've explored, {topic} represents a significant opportunity for innovation and growth. The future looks promising for those who embrace these changes."
        },
        "email": {
            "subject": f"Important Update: {topic}",
            "greeting": "Dear Team,",
            "body": f"I wanted to share some important information about {topic} that I believe will be valuable for our organization.",
            "closing": "Best regards,\n[Your Name]"
        },
        "social_media": {
            "platforms": {
                "twitter": f"🚀 Exciting developments in {topic}! Here's what you need to know... #innovation #tech",
                "linkedin": f"Professional insights on {topic} and its impact on our industry. What are your thoughts?",
                "facebook": f"Breaking down {topic} in simple terms. Swipe to learn more! 👆"
            }
        }
    }
    
    content = content_templates.get(content_type, {
        "title": f"Content about {topic}",
        "body": f"This is a {length} {content_type} about {topic} written in a {tone} tone."
    })
    
    return {
        "status": "success",
        "content_type": content_type,
        "topic": topic,
        "length": length,
        "tone": tone,
        "content": content,
        "timestamp": datetime.now().isoformat(),
        "word_count": len(str(content).split())
    }


def edit_content(content: str, style: str = "improve", focus: str = "clarity") -> Dict:
    """Edits and improves existing content."""
    print(f"--- Tool: edit_content called with style '{style}' and focus '{focus}' ---")
    
    # Simulate content editing
    edited_content = f"EDITED: {content}"
    
    improvements = [
        "Enhanced clarity and readability",
        "Improved sentence structure",
        "Added transitional phrases",
        "Strengthened key arguments"
    ]
    
    return {
        "status": "success",
        "original_content": content,
        "edited_content": edited_content,
        "style": style,
        "focus": focus,
        "improvements": improvements,
        "timestamp": datetime.now().isoformat()
    }


def create_outline(topic: str, content_type: str, sections: int = 5) -> Dict:
    """Creates a structured outline for content."""
    print(f"--- Tool: create_outline called for {content_type} about {topic} ---")
    
    # Generate outline structure
    outline = {
        "topic": topic,
        "content_type": content_type,
        "sections": [
            {
                "title": f"Introduction to {topic}",
                "key_points": [
                    f"Definition of {topic}",
                    f"Current relevance",
                    f"Scope of discussion"
                ]
            },
            {
                "title": f"Background and Context",
                "key_points": [
                    f"Historical development",
                    f"Current state",
                    f"Key players"
                ]
            },
            {
                "title": f"Core Concepts",
                "key_points": [
                    f"Fundamental principles",
                    f"Key components",
                    f"Important terminology"
                ]
            },
            {
                "title": f"Applications and Use Cases",
                "key_points": [
                    f"Real-world examples",
                    f"Industry applications",
                    f"Success stories"
                ]
            },
            {
                "title": f"Future Outlook",
                "key_points": [
                    f"Emerging trends",
                    f"Predictions",
                    f"Recommendations"
                ]
            }
        ]
    }
    
    return {
        "status": "success",
        "outline": outline,
        "timestamp": datetime.now().isoformat()
    }


# Create the writing agent
writing_agent = Agent(
    name="writing_agent",
    model="gemini-2.0-flash",
    description="An agent specialized in content creation, writing, and editing.",
    instruction="""
    You are a writing specialist agent that helps users create high-quality content across various formats.
    
    Your capabilities include:
    1. Content generation for different formats (blog posts, emails, social media)
    2. Content editing and improvement
    3. Outline creation and content structuring
    
    When creating content:
    - Always consider the target audience and purpose
    - Maintain appropriate tone and style for the content type
    - Ensure clarity, coherence, and engagement
    - Include relevant examples and supporting details
    - Optimize for the specified length and format
    
    Content types you can handle:
    - Blog posts: Informative, engaging articles
    - Emails: Professional communication
    - Social media: Platform-specific content
    - Reports: Structured, data-driven content
    
    Always provide well-structured, polished content that meets the user's requirements.
    """,
    tools=[generate_content, edit_content, create_outline],
) 