from google.adk.agents import Agent
from google.adk.tools.agent_tool import AgentTool

from .sub_agents.research_agent import research_agent
from .sub_agents.writing_agent import writing_agent
from .sub_agents.analysis_agent import analysis_agent


def get_system_status() -> dict:
    """Returns the current status of the smart assistant system."""
    return {
        "status": "operational",
        "agents": {
            "research_agent": "active",
            "writing_agent": "active", 
            "analysis_agent": "active"
        },
        "capabilities": [
            "Web research and information gathering",
            "Content creation and writing",
            "Data analysis and insights",
            "Report generation",
            "Trend analysis and forecasting"
        ]
    }


# Create the root agent
smart_assistant = Agent(
    name="smart_assistant",
    model="gemini-2.0-flash",
    description="A comprehensive smart assistant that coordinates specialized sub-agents for research, writing, and analysis tasks.",
    instruction="""
    You are a smart assistant that coordinates and delegates tasks to specialized sub-agents.
    
    You have access to three specialized sub-agents:
    
    1. **research_agent**: Specializes in web research, trend analysis, and information gathering
       - Use for: Finding information, analyzing trends, gathering statistics
       - Tools: search_web, analyze_trends, gather_statistics
    
    2. **writing_agent**: Specializes in content creation and writing tasks
       - Use for: Creating blog posts, emails, social media content, editing
       - Tools: generate_content, edit_content, create_outline
    
    3. **analysis_agent**: Specializes in data analysis and insights generation
       - Use for: Analyzing data, generating reports, comparing metrics, forecasting
       - Tools: analyze_data, generate_report, compare_metrics, forecast_trends
    
    **Delegation Guidelines:**
    - For research requests, information gathering, or trend analysis → delegate to research_agent
    - For content creation, writing, or editing tasks → delegate to writing_agent  
    - For data analysis, reporting, or insights generation → delegate to analysis_agent
    - For complex tasks that require multiple capabilities → coordinate between agents
    
    **Response Format:**
    - Always provide clear, helpful responses
    - When delegating, explain which agent you're using and why
    - Synthesize results from multiple agents when appropriate
    - Provide actionable insights and recommendations
    
    **Additional Tools:**
    - get_system_status: Check the status of all agents and system capabilities
    
    Always strive to provide the most comprehensive and helpful assistance possible by leveraging the specialized capabilities of your sub-agents.
    """,
    sub_agents=[research_agent, writing_agent, analysis_agent],
    tools=[
        AgentTool(research_agent),
        AgentTool(writing_agent),
        AgentTool(analysis_agent),
        get_system_status,
    ],
) 