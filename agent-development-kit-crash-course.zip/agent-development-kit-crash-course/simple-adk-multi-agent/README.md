# Simple ADK Multi-Agent System

A simple multi-agent system using Google Agent Development Kit (ADK) with built-in in-memory session service and FastAPI server endpoints, following the ADK template structure.

## Architecture

- **Root Agent**: Analyzes queries and delegates to specialized sub-agents
- **Email Agent**: Generates email content and campaigns
- **Blog Agent**: Creates long-form blog articles and content
- **ADK InMemorySessionService**: Built-in session management from ADK
- **FastAPI Server**: REST API endpoints for agent interaction

## Project Structure

```
simple-adk-multi-agent/
├── manager/                    # Root agent package
│   ├── __init__.py
│   ├── agent.py               # Root agent definition
│   ├── env_example.txt        # Environment variables example
│   └── sub_agents/            # Sub-agents directory
│       ├── __init__.py
│       ├── email_agent/
│       │   ├── __init__.py
│       │   └── agent.py       # Email agent
│       └── blog_agent/
│           ├── __init__.py
│           └── agent.py       # Blog agent
├── server/
│   ├── main.py               # FastAPI server
│   └── test_server.py        # Server test script
├── requirements.txt          # Dependencies
└── README.md                # This file
```

## Quick Start

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Set up environment variables**:
   ```bash
   cd manager
   cp env_example.txt .env
   # Edit .env with your GOOGLE_API_KEY
   ```

3. **Start the FastAPI server**:
   ```bash
   cd server
   python main.py
   ```

4. **Test the server**:
   ```bash
   python test_server.py
   ```

## API Endpoints

- `POST /api/v1/chat`: Send message to agent
- `GET /api/v1/health`: Health check
- `GET /api/v1/sessions/{session_id}`: Get session data
- `DELETE /api/v1/sessions/{session_id}`: Delete session (auto-managed by ADK)

## Usage Example

```bash
curl -X POST "http://localhost:8000/api/v1/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Create an email about our new product launch",
    "session_id": "user123"
  }'
```

## Agent Capabilities

### Root Agent (Manager)
- Query analysis and context understanding
- Delegation to appropriate sub-agents
- Workflow coordination

### Email Agent
- Email campaigns and newsletters
- Marketing emails
- Professional communications

### Blog Agent
- Blog articles and long-form content
- Technical documentation
- Thought leadership pieces

## Session Management

This system uses ADK's built-in `InMemorySessionService` which provides:
- Automatic session management
- State persistence during application runtime
- No external dependencies
- Seamless integration with ADK's Runner

## Benefits of Using ADK's Built-in Session Service

1. **No Custom Code**: Uses ADK's tested and maintained session service
2. **Automatic Management**: Sessions are handled automatically by ADK
3. **Consistent Interface**: Follows ADK's standard session patterns
4. **Future-Proof**: Will automatically benefit from ADK updates
5. **Simplified Architecture**: No need to maintain custom session logic 