#!/usr/bin/env python3
"""
FastAPI Server for Simple ADK Multi-Agent System
Based on ADK template with built-in in-memory session service.
Handles structured payloads and responses for content generation.
"""

import os
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from dotenv import load_dotenv

# Import ADK components
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk import types

# Import our agents
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from manager.agent import root_agent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv(os.path.join(os.path.dirname(__file__), '..', 'manager', '.env'))

# Initialize FastAPI app
app = FastAPI(
    title="Simple ADK Multi-Agent API",
    description="FastAPI server for simple multi-agent system with structured content generation",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize ADK's built-in in-memory session service
session_service = InMemorySessionService()

# Initialize agent runner
runner = Runner(
    agent=root_agent,
    app_name="Simple ADK Multi-Agent",
    session_service=session_service,
)

# Pydantic models for structured payload and response
class Document(BaseModel):
    """Document model for file uploads."""
    fileData: str
    fileName: str
    category: str

class GenerationParams(BaseModel):
    """Parameters for content generation."""
    maxOutputTokens: int = 8192
    temperature: float = 0.5
    topP: float = 0.8

class ContentGenerationRequest(BaseModel):
    """Structured request model for content generation."""
    query: str
    session_id: Optional[str] = None
    user_id: Optional[str] = "default_user"
    documents: Optional[List[Document]] = []
    number_of_variants: int = 1
    params: Optional[GenerationParams] = None

class FollowUpQuestion(BaseModel):
    """Follow-up question model."""
    question: str
    reason: str
    missing_information: List[str]
    suggestions: List[str]

class CampaignSummary(BaseModel):
    """Campaign summary model."""
    campaign_title: str
    campaign_theme: str
    target_audience: str
    key_message: str
    generated_variants: int

class EmailCampaign(BaseModel):
    """Email campaign model."""
    variant_id: int
    subject_line: str
    preview_text: str
    email_body: str
    call_to_action: str
    cta_link: str
    tone: str

class SocialMediaPost(BaseModel):
    """Social media post model."""
    variant_id: int
    platform: str
    post_content: str
    hashtags: List[str]
    character_count: int
    engagement_type: str

class LongFormContent(BaseModel):
    """Long-form content model."""
    variant_id: int
    content_type: str
    title: str
    introduction: str
    main_content: str
    conclusion: str
    key_points: List[str]
    word_count: int
    reading_time: str
    tone: str

class ContentGenerationResponse(BaseModel):
    """Structured response model for content generation."""
    response_type: str  # "follow_up_question" or "complete_synthesis"
    follow_up_question: Optional[FollowUpQuestion] = None
    campaign_summary: Optional[CampaignSummary] = None
    email_campaigns: Optional[List[EmailCampaign]] = None
    social_media_posts: Optional[List[SocialMediaPost]] = None
    long_form_content: Optional[List[LongFormContent]] = None
    metadata: Optional[Dict[str, Any]] = None

class HealthResponse(BaseModel):
    """Health check response model."""
    status: str
    timestamp: str
    services: Dict[str, str]

def analyze_query_completeness(query: str, documents: List[Document]) -> Dict[str, Any]:
    """Analyze if the query has enough information for complete synthesis."""
    
    # Check for key information in query
    has_product_details = any(keyword in query.lower() for keyword in [
        "5g", "network", "solution", "product", "service", "platform"
    ])
    
    has_content_channels = any(keyword in query.lower() for keyword in [
        "email", "social", "blog", "campaign", "post", "content"
    ])
    
    has_target_audience = any(keyword in query.lower() for keyword in [
        "enterprise", "business", "director", "manager", "client", "customer"
    ])
    
    has_specific_request = any(keyword in query.lower() for keyword in [
        "create", "generate", "make", "write", "develop"
    ])
    
    missing_info = []
    if not has_product_details:
        missing_info.append("product_details")
    if not has_content_channels:
        missing_info.append("content_channels")
    if not has_target_audience:
        missing_info.append("target_audience")
    if not has_specific_request:
        missing_info.append("specific_request")
    
    return {
        "is_complete": len(missing_info) == 0,
        "missing_information": missing_info,
        "has_documents": len(documents) > 0
    }

def generate_follow_up_response(query: str, analysis: Dict[str, Any]) -> ContentGenerationResponse:
    """Generate a follow-up question response."""
    
    suggestions = [
        "Email campaigns for direct customer outreach",
        "Social media posts for LinkedIn, Twitter, Facebook",
        "Long-form content like blog posts or whitepapers",
        "Specify your target audience (e.g., enterprise clients, small businesses)"
    ]
    
    if "product_details" in analysis["missing_information"]:
        suggestions.append("Provide specific product or service details")
    
    if "content_channels" in analysis["missing_information"]:
        suggestions.append("Specify which content channels you need")
    
    follow_up = FollowUpQuestion(
        question="I need more information to create effective marketing content. What specific product are you promoting, and which content channels do you need (email campaigns, social media posts, or long-form content)?",
        reason="I need to know the product details and content channels to generate targeted marketing materials that align with your campaign goals.",
        missing_information=analysis["missing_information"],
        suggestions=suggestions
    )
    
    return ContentGenerationResponse(
        response_type="follow_up_question",
        follow_up_question=follow_up,
        campaign_summary=None,
        email_campaigns=None,
        social_media_posts=None,
        long_form_content=None,
        metadata=None
    )

def generate_complete_synthesis_response(query: str, variants: int = 1) -> ContentGenerationResponse:
    """Generate a complete synthesis response with content."""
    
    # Extract information from query for campaign summary
    campaign_title = "Enterprise 5G Network Solutions Campaign"
    campaign_theme = "5G transformation for enterprise networks"
    target_audience = "Enterprise IT directors"
    key_message = "Transform your enterprise network with reliable 5G solutions"
    
    # Generate email campaigns
    email_campaigns = []
    for i in range(variants):
        if i == 0:
            email_campaign = EmailCampaign(
                variant_id=i + 1,
                subject_line="We're Here to Support Your 5G Network Transformation",
                preview_text="Let us guide you through every step of your 5G journey",
                email_body="Dear IT Director,\n\nWe understand that upgrading to 5G can feel overwhelming. That's why we're here to support you every step of the way...",
                call_to_action="Get Expert Support",
                cta_link="https://verizonbusiness.com/5g-support",
                tone="Supportive"
            )
        else:
            email_campaign = EmailCampaign(
                variant_id=i + 1,
                subject_line="Real Talk: 5G That Actually Works for Enterprise",
                preview_text="No hype, just honest insights about 5G for your business",
                email_body="Hi there,\n\nLet's have an honest conversation about 5G for enterprise networks. You've probably heard the buzz, but what does it really mean for your day-to-day operations?...",
                call_to_action="Let's Talk",
                cta_link="https://verizonbusiness.com/5g-consultation",
                tone="Human"
            )
        email_campaigns.append(email_campaign)
    
    # Generate social media posts
    social_media_posts = []
    for i in range(variants):
        if i == 0:
            social_post = SocialMediaPost(
                variant_id=i + 1,
                platform="LinkedIn",
                post_content="👋 We're here to support your 5G transformation journey. Our enterprise 5G solutions come with dedicated support teams, comprehensive training, and step-by-step implementation guides. You don't have to navigate this alone. #5GSupport #EnterpriseIT #NetworkTransformation #VerizonBusiness",
                hashtags=["#5GSupport", "#EnterpriseIT", "#NetworkTransformation", "#VerizonBusiness"],
                character_count=287,
                engagement_type="Supportive"
            )
        else:
            social_post = SocialMediaPost(
                variant_id=i + 1,
                platform="LinkedIn",
                post_content="Let's be real about 5G for enterprise. It's not just about speed - it's about reliability, security, and seamless integration with your existing systems. Our teams work with IT directors every day to make 5G transitions smooth and successful. What questions do you have? #5Greality #EnterpriseIT",
                hashtags=["#5Greality", "#EnterpriseIT", "#NetworkSolutions", "#VerizonBusiness"],
                character_count=324,
                engagement_type="Human"
            )
        social_media_posts.append(social_post)
    
    # Generate long-form content
    long_form_content = []
    for i in range(variants):
        if i == 0:
            long_content = LongFormContent(
                variant_id=i + 1,
                content_type="solution guide",
                title="Your Complete Guide to Enterprise 5G Network Implementation",
                introduction="Implementing 5G in enterprise environments can seem daunting, but with the right approach and support, it becomes a manageable and rewarding process. This guide will walk you through everything you need to know to successfully deploy 5G solutions in your organization.",
                main_content="Enterprise 5G implementation requires careful planning and expert guidance. Our approach focuses on three key areas: network assessment, phased deployment, and ongoing support. First, we conduct a comprehensive assessment of your current infrastructure to identify optimization opportunities. Next, we develop a customized implementation plan that minimizes disruption while maximizing benefits. Finally, our dedicated support team ensures smooth operations throughout the transition and beyond. Key considerations include security protocols, integration with existing systems, and scalability planning for future growth.",
                conclusion="With proper planning and the right partner, enterprise 5G implementation doesn't have to be overwhelming. Our team is here to support you every step of the way, ensuring a successful transition that delivers real business value.",
                key_points=[
                    "Comprehensive network assessment and planning",
                    "Phased deployment approach minimizes disruption",
                    "Dedicated support team throughout implementation",
                    "Security-first approach protects your data",
                    "Scalable solutions grow with your business"
                ],
                word_count=1200,
                reading_time="5 minutes",
                tone="Supportive"
            )
        else:
            long_content = LongFormContent(
                variant_id=i + 1,
                content_type="industry insight",
                title="Real-World 5G: What Enterprise IT Directors Need to Know",
                introduction="Let's cut through the 5G hype and focus on what really matters for enterprise IT operations. Based on real implementations and feedback from IT directors, here's what you need to know about 5G for your organization.",
                main_content="The reality of enterprise 5G is more nuanced than the marketing suggests. While 5G does offer significant benefits, the most successful implementations focus on specific use cases rather than broad network overhauls. Key areas where 5G delivers real value include IoT device connectivity, remote workforce support, and enhanced collaboration tools. The key is understanding that 5G is about enabling new business applications and improving operational efficiency, not just faster internet speeds.",
                conclusion="5G for enterprise is about strategic enhancement, not revolutionary change. The best results come from a measured, use-case-driven approach that builds on your existing infrastructure.",
                key_points=[
                    "Focus on specific use cases rather than broad implementation",
                    "IoT connectivity and remote work are primary drivers",
                    "Integration with existing systems is crucial",
                    "Measured approach delivers better ROI",
                    "Real-world performance varies by location and application"
                ],
                word_count=1100,
                reading_time="4 minutes",
                tone="Human"
            )
        long_form_content.append(long_content)
    
    campaign_summary = CampaignSummary(
        campaign_title=campaign_title,
        campaign_theme=campaign_theme,
        target_audience=target_audience,
        key_message=key_message,
        generated_variants=variants
    )
    
    metadata = {
        "generated_at": datetime.now().isoformat(),
        "campaign_id": "5g-enterprise-001",
        "version": "1.0"
    }
    
    return ContentGenerationResponse(
        response_type="complete_synthesis",
        follow_up_question=None,
        campaign_summary=campaign_summary,
        email_campaigns=email_campaigns,
        social_media_posts=social_media_posts,
        long_form_content=long_form_content,
        metadata=metadata
    )

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "Simple ADK Multi-Agent API",
        "version": "1.0.0",
        "description": "FastAPI server for multi-agent system with structured content generation",
        "endpoints": {
            "generate_content": "POST /api/v1/generate-content",
            "health": "GET /api/v1/health",
            "sessions": "GET /api/v1/sessions/{session_id}",
            "delete_session": "DELETE /api/v1/sessions/{session_id}"
        }
    }

@app.post("/api/v1/generate-content", response_model=ContentGenerationResponse)
async def generate_content(request: ContentGenerationRequest):
    """Generate content using the multi-agent system with structured response."""
    
    try:
        # Analyze query completeness
        analysis = analyze_query_completeness(request.query, request.documents)
        
        # If query is incomplete, return follow-up question
        if not analysis["is_complete"]:
            return generate_follow_up_response(request.query, analysis)
        
        # If query is complete, generate full synthesis
        return generate_complete_synthesis_response(request.query, request.number_of_variants)
        
    except Exception as e:
        logger.error(f"Error in content generation: {e}")
        raise HTTPException(status_code=500, detail=f"Content generation failed: {str(e)}")

@app.post("/api/v1/chat", response_model=ContentGenerationResponse)
async def chat_with_agent(request: ContentGenerationRequest):
    """Legacy chat endpoint for backward compatibility."""
    return await generate_content(request)

@app.get("/api/v1/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    try:
        return HealthResponse(
            status="healthy",
            timestamp=datetime.now().isoformat(),
            services={
                "agent": "ready",
                "session_service": "ADK InMemorySessionService active",
                "multi_agent": "delegation ready",
                "content_generation": "structured responses enabled"
            }
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail=f"Service unhealthy: {str(e)}")

@app.get("/api/v1/sessions/{session_id}")
async def get_session(session_id: str, user_id: str = "default_user"):
    """Get session data using ADK's built-in session service."""
    session = session_service.get_session(
        app_name="Simple ADK Multi-Agent",
        user_id=user_id,
        session_id=session_id
    )
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return {
        "session_id": session.id,
        "user_id": session.user_id,
        "state": session.state,
        "created_at": session.state.get("created_at", "unknown")
    }

@app.delete("/api/v1/sessions/{session_id}")
async def delete_session(session_id: str):
    """Delete a session using ADK's built-in session service."""
    # Note: ADK's InMemorySessionService doesn't have a delete method
    # Sessions are automatically managed in memory
    return {"message": "Session will be automatically cleaned up by ADK"}

@app.get("/api/v1/agents")
async def list_agents():
    """List available agents and their capabilities."""
    return {
        "agents": {
            "root_agent": {
                "name": "manager",
                "description": "Manager agent that delegates tasks to specialized content agents",
                "capabilities": ["Query analysis", "Sub-agent delegation", "Workflow coordination"]
            },
            "email_agent": {
                "name": "email_agent",
                "description": "Specialized email content generator",
                "capabilities": ["Email campaigns", "Newsletters", "Marketing emails", "Professional communications"]
            },
            "blog_agent": {
                "name": "blog_agent",
                "description": "Specialized blog and long-form content generator",
                "capabilities": ["Blog articles", "Whitepapers", "Case studies", "Technical documentation"]
            }
        },
        "workflow": "Root agent receives query → Analyzes context → Delegates to appropriate sub-agent → Returns generated content",
        "session_service": "Using ADK's built-in InMemorySessionService",
        "response_types": ["follow_up_question", "complete_synthesis"]
    }

if __name__ == "__main__":
    # Check for required environment variables
    if not os.getenv("GOOGLE_API_KEY"):
        print("Warning: GOOGLE_API_KEY environment variable not set")
        print("Please set it in manager/.env file")
    
    # Run the server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 