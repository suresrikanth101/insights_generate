#!/usr/bin/env python3
"""
Test script for Simple ADK Multi-Agent Server with Structured Content Generation
"""

import requests
import json
import time
from typing import Dict, Any

# API base URL
BASE_URL = "http://localhost:8000"

def test_health_check():
    """Test the health check endpoint."""
    print("Testing health check...")
    try:
        response = requests.get(f"{BASE_URL}/api/v1/health")
        if response.status_code == 200:
            print("✅ Health check passed")
            print(f"Status: {response.json()['status']}")
            print(f"Services: {response.json()['services']}")
        else:
            print(f"❌ Health check failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Health check error: {e}")

def test_agents_list():
    """Test the agents list endpoint."""
    print("\nTesting agents list...")
    try:
        response = requests.get(f"{BASE_URL}/api/v1/agents")
        if response.status_code == 200:
            print("✅ Agents list retrieved")
            agents = response.json()['agents']
            for agent_name, agent_info in agents.items():
                print(f"  {agent_name}: {agent_info['description']}")
            print(f"Workflow: {response.json().get('workflow', 'N/A')}")
            print(f"Response types: {response.json().get('response_types', 'N/A')}")
        else:
            print(f"❌ Agents list failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Agents list error: {e}")

def test_follow_up_question():
    """Test incomplete request that should trigger follow-up question."""
    print(f"\nTesting follow-up question (incomplete request)...")
    
    # Example 1: Incomplete request
    payload = {
        "query": "I need marketing content for our new product",
        "session_id": "test_session_1",
        "user_id": "johndoe@verizon.com",
        "documents": [
            {
                "fileData": "document1",
                "fileName": "press release.pdf",
                "category": "pdf"
            }
        ],
        "number_of_variants": 1,
        "params": {
            "maxOutputTokens": 8192,
            "temperature": 0.5,
            "topP": 0.8
        }
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/v1/generate-content",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Follow-up question generated successfully")
            print(f"Response type: {result['response_type']}")
            if result['follow_up_question']:
                print(f"Question: {result['follow_up_question']['question'][:100]}...")
                print(f"Missing info: {result['follow_up_question']['missing_information']}")
                print(f"Suggestions: {len(result['follow_up_question']['suggestions'])} provided")
            return result
        else:
            print(f"❌ Follow-up question failed: {response.status_code}")
            print(f"Error: {response.text}")
            return None
            
    except Exception as e:
        print(f"❌ Follow-up question error: {e}")
        return None

def test_complete_synthesis():
    """Test complete request that should generate full content."""
    print(f"\nTesting complete synthesis (complete request)...")
    
    # Example 2: Complete request
    payload = {
        "query": "Create 2 marketing content variants for 5G network solutions targeting enterprise IT directors. I need email campaigns, social media posts, and long-form content.",
        "session_id": "test_session_2",
        "user_id": "johndoe@verizon.com",
        "documents": [],
        "number_of_variants": 2,
        "params": {
            "maxOutputTokens": 8192,
            "temperature": 0.5,
            "topP": 0.8
        }
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/v1/generate-content",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Complete synthesis generated successfully")
            print(f"Response type: {result['response_type']}")
            
            if result['campaign_summary']:
                print(f"Campaign: {result['campaign_summary']['campaign_title']}")
                print(f"Target audience: {result['campaign_summary']['target_audience']}")
                print(f"Generated variants: {result['campaign_summary']['generated_variants']}")
            
            if result['email_campaigns']:
                print(f"Email campaigns: {len(result['email_campaigns'])} generated")
                for email in result['email_campaigns']:
                    print(f"  Variant {email['variant_id']}: {email['subject_line']}")
            
            if result['social_media_posts']:
                print(f"Social media posts: {len(result['social_media_posts'])} generated")
                for post in result['social_media_posts']:
                    print(f"  Variant {post['variant_id']}: {post['platform']} ({post['character_count']} chars)")
            
            if result['long_form_content']:
                print(f"Long-form content: {len(result['long_form_content'])} generated")
                for content in result['long_form_content']:
                    print(f"  Variant {content['variant_id']}: {content['title']} ({content['word_count']} words)")
            
            return result
        else:
            print(f"❌ Complete synthesis failed: {response.status_code}")
            print(f"Error: {response.text}")
            return None
            
    except Exception as e:
        print(f"❌ Complete synthesis error: {e}")
        return None

def test_legacy_chat_endpoint():
    """Test the legacy chat endpoint for backward compatibility."""
    print(f"\nTesting legacy chat endpoint...")
    
    payload = {
        "query": "Create an email about our new 5G services",
        "session_id": "test_session_3",
        "user_id": "test_user"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/v1/chat",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Legacy chat endpoint works")
            print(f"Response type: {result['response_type']}")
            return result
        else:
            print(f"❌ Legacy chat failed: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"❌ Legacy chat error: {e}")
        return None

def test_session_management(session_id: str):
    """Test session management endpoints."""
    print(f"\nTesting session management for session: {session_id}")
    
    try:
        # Get session
        response = requests.get(f"{BASE_URL}/api/v1/sessions/{session_id}")
        if response.status_code == 200:
            print("✅ Session retrieved")
            session_data = response.json()
            print(f"Session ID: {session_data['session_id']}")
            print(f"User ID: {session_data['user_id']}")
        else:
            print(f"❌ Session retrieval failed: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Session management error: {e}")

def test_delete_session(session_id: str):
    """Test session deletion."""
    print(f"\nTesting session deletion for session: {session_id}")
    
    try:
        response = requests.delete(f"{BASE_URL}/api/v1/sessions/{session_id}")
        if response.status_code == 200:
            print("✅ Session deletion response received")
            print(f"Message: {response.json().get('message', 'N/A')}")
        else:
            print(f"❌ Session deletion failed: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Session deletion error: {e}")

def run_comprehensive_test():
    """Run a comprehensive test of all endpoints."""
    print("🚀 Starting comprehensive API test...")
    print("=" * 60)
    
    # Test 1: Health check
    test_health_check()
    
    # Test 2: Agents list
    test_agents_list()
    
    # Test 3: Follow-up question (incomplete request)
    test_follow_up_question()
    time.sleep(1)
    
    # Test 4: Complete synthesis (complete request)
    test_complete_synthesis()
    time.sleep(1)
    
    # Test 5: Legacy chat endpoint
    test_legacy_chat_endpoint()
    time.sleep(1)
    
    # Test 6: Session management
    test_session_management("test_session_1")
    test_session_management("test_session_2")
    
    # Test 7: Session deletion
    test_delete_session("test_session_1")
    test_delete_session("test_session_2")
    
    print("\n" + "=" * 60)
    print("✅ Comprehensive test completed!")

if __name__ == "__main__":
    # Check if server is running
    try:
        response = requests.get(f"{BASE_URL}/")
        if response.status_code == 200:
            print("✅ Server is running")
            run_comprehensive_test()
        else:
            print("❌ Server is not responding properly")
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to server. Make sure it's running on http://localhost:8000")
        print("Start the server with: cd server && python main.py")
    except Exception as e:
        print(f"❌ Error connecting to server: {e}") 