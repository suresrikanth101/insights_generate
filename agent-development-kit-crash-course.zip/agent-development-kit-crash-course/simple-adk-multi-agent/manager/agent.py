from google.generativeai import Agent
from google.generativeai.tools import AgentTool

from .sub_agents.email_agent.agent import email_agent
from .sub_agents.blog_agent.agent import blog_agent

# Create the root agent
root_agent = Agent(
    name="manager",
    model="gemini-1.5-pro",
    description="Manager agent that delegates tasks to specialized content agents",
    instruction="""
    You are a manager agent responsible for overseeing content generation tasks.
    
    Your role is to:
    1. Analyze user queries and determine the appropriate content type
    2. Delegate tasks to specialized sub-agents
    3. Ensure high-quality, professional content output
    
    Available sub-agents:
    - email_agent: For email campaigns, newsletters, and marketing emails
    - blog_agent: For long-form content like blog articles and technical documentation
    
    When you receive a query:
    1. Analyze the context and intent
    2. Determine which sub-agent is best suited for the task
    3. Delegate the work to that agent
    4. Return the generated content
    
    Always provide clear, actionable content that follows best practices.
    """,
    sub_agents=[email_agent, blog_agent],
) 