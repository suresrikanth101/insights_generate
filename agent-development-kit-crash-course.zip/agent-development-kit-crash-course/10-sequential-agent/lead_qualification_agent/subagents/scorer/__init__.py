"""Scorer agent for lead qualification."""

from .agent import lead_scorer_agent
