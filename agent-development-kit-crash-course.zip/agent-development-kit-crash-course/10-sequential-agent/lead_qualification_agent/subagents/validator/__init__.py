"""Validator agent for lead qualification."""

from .agent import lead_validator_agent
