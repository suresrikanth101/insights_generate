import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
import redis
from dataclasses import dataclass, asdict
from collections import namedtuple

# Define session structures to match ADK's expected format
@dataclass
class Session:
    """Represents a session with its metadata and state."""
    id: str
    app_name: str
    user_id: str
    state: Dict[str, Any]
    created_at: datetime
    updated_at: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'app_name': self.app_name,
            'user_id': self.user_id,
            'state': self.state,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Session':
        """Create session from dictionary."""
        return cls(
            id=data['id'],
            app_name=data['app_name'],
            user_id=data['user_id'],
            state=data['state'],
            created_at=datetime.fromisoformat(data['created_at']),
            updated_at=datetime.fromisoformat(data['updated_at'])
        )

# Create a named tuple for list_sessions response to match ADK's expected format
SessionList = namedtuple('SessionList', ['sessions'])

class RedisSessionService:
    """
    Redis-based session service that implements the same interface as ADK's session services.
    
    This service stores session data in Redis cache instead of SQL database.
    """
    
    def __init__(self, redis_url: str = "redis://localhost:6379/0", **redis_kwargs):
        """
        Initialize Redis session service.
        
        Args:
            redis_url: Redis connection URL (default: redis://localhost:6379/0)
            **redis_kwargs: Additional Redis client configuration
        """
        self.redis_client = redis.from_url(redis_url, decode_responses=True, **redis_kwargs)
        self.session_prefix = "adk_session:"
        self.user_sessions_prefix = "adk_user_sessions:"
        
        # Test the connection
        try:
            self.redis_client.ping()
            print("✓ Connected to Redis successfully")
        except redis.ConnectionError as e:
            print(f"✗ Failed to connect to Redis: {e}")
            raise
    
    def _get_session_key(self, session_id: str) -> str:
        """Generate Redis key for a session."""
        return f"{self.session_prefix}{session_id}"
    
    def _get_user_sessions_key(self, app_name: str, user_id: str) -> str:
        """Generate Redis key for user's session list."""
        return f"{self.user_sessions_prefix}{app_name}:{user_id}"
    
    def create_session(
        self, 
        app_name: str, 
        user_id: str, 
        session_id: Optional[str] = None, 
        state: Optional[Dict[str, Any]] = None
    ) -> Session:
        """
        Create a new session.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Optional session ID (generated if not provided)
            state: Initial session state
            
        Returns:
            Created session object
        """
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        if state is None:
            state = {}
        
        now = datetime.now()
        session = Session(
            id=session_id,
            app_name=app_name,
            user_id=user_id,
            state=state,
            created_at=now,
            updated_at=now
        )
        
        # Store session in Redis
        session_key = self._get_session_key(session_id)
        session_data = json.dumps(session.to_dict())
        self.redis_client.set(session_key, session_data)
        
        # Add session to user's session list
        user_sessions_key = self._get_user_sessions_key(app_name, user_id)
        self.redis_client.sadd(user_sessions_key, session_id)
        
        print(f"✓ Created session {session_id} for user {user_id} in app {app_name}")
        return session
    
    def get_session(self, app_name: str, user_id: str, session_id: str) -> Session:
        """
        Get an existing session.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier
            
        Returns:
            Session object
            
        Raises:
            ValueError: If session not found
        """
        session_key = self._get_session_key(session_id)
        session_data = self.redis_client.get(session_key)
        
        if not session_data:
            raise ValueError(f"Session {session_id} not found")
        
        session_dict = json.loads(session_data)
        session = Session.from_dict(session_dict)
        
        # Verify the session belongs to the specified user and app
        if session.user_id != user_id or session.app_name != app_name:
            raise ValueError(f"Session {session_id} does not belong to user {user_id} in app {app_name}")
        
        return session
    
    def list_sessions(self, app_name: str, user_id: str) -> SessionList:
        """
        List all sessions for a user in an application.
        
        Args:
            app_name: Application name
            user_id: User identifier
            
        Returns:
            SessionList object containing list of sessions
        """
        user_sessions_key = self._get_user_sessions_key(app_name, user_id)
        session_ids = self.redis_client.smembers(user_sessions_key)
        
        sessions = []
        for session_id in session_ids:
            try:
                session = self.get_session(app_name, user_id, session_id)
                sessions.append(session)
            except ValueError:
                # Session might have been deleted, remove from user's session list
                self.redis_client.srem(user_sessions_key, session_id)
                continue
        
        # Sort sessions by creation date (newest first)
        sessions.sort(key=lambda s: s.created_at, reverse=True)
        
        return SessionList(sessions=sessions)
    
    def update_session_state(self, session_id: str, state: Dict[str, Any]) -> None:
        """
        Update session state.
        
        Args:
            session_id: Session identifier
            state: New session state
        """
        session_key = self._get_session_key(session_id)
        session_data = self.redis_client.get(session_key)
        
        if not session_data:
            raise ValueError(f"Session {session_id} not found")
        
        session_dict = json.loads(session_data)
        session_dict['state'] = state
        session_dict['updated_at'] = datetime.now().isoformat()
        
        self.redis_client.set(session_key, json.dumps(session_dict))
    
    def delete_session(self, session_id: str) -> None:
        """
        Delete a session.
        
        Args:
            session_id: Session identifier
        """
        session_key = self._get_session_key(session_id)
        session_data = self.redis_client.get(session_key)
        
        if session_data:
            session_dict = json.loads(session_data)
            app_name = session_dict['app_name']
            user_id = session_dict['user_id']
            
            # Remove from user's session list
            user_sessions_key = self._get_user_sessions_key(app_name, user_id)
            self.redis_client.srem(user_sessions_key, session_id)
        
        # Delete the session
        self.redis_client.delete(session_key)
        print(f"✓ Deleted session {session_id}")
    
    def clear_all_sessions(self, app_name: str, user_id: str) -> None:
        """
        Clear all sessions for a user in an application.
        
        Args:
            app_name: Application name
            user_id: User identifier
        """
        sessions = self.list_sessions(app_name, user_id)
        for session in sessions.sessions:
            self.delete_session(session.id)
        print(f"✓ Cleared all sessions for user {user_id} in app {app_name}")
    
    def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on Redis connection.
        
        Returns:
            Dictionary with health status information
        """
        try:
            # Test basic operations
            self.redis_client.ping()
            info = self.redis_client.info()
            
            return {
                "status": "healthy",
                "redis_version": info.get("redis_version", "unknown"),
                "connected_clients": info.get("connected_clients", 0),
                "used_memory_human": info.get("used_memory_human", "unknown"),
                "uptime_in_seconds": info.get("uptime_in_seconds", 0)
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            } 