import os
from typing import Dict, Any
from google.generativeai import Agent
from utils import get_current_time, get_formatted_time

# Import sub-agents
from ..sub_agents.email_agent.agent import email_agent
from ..sub_agents.social_agent.agent import social_agent
from ..sub_agents.blog_agent.agent import blog_agent

class RootAgent:
    def __init__(self):
        self.agent = Agent(
            model="gemini-1.5-pro",
            tools=[get_current_time, get_formatted_time],
            instructions="""
            You are a content generation manager that coordinates between specialized sub-agents.
            
            Your role is to:
            1. Analyze the user's query and determine the appropriate content type
            2. Delegate the task to the correct specialized agent
            3. Ensure high-quality, professional content output
            
            Available sub-agents:
            - email_agent: For email campaigns, newsletters, and marketing emails
            - social_agent: For social media posts (Twitter, LinkedIn, Facebook, Instagram)
            - blog_agent: For long-form content like blog articles, whitepapers, and case studies
            
            When you receive a query:
            1. Analyze the context and intent
            2. Determine which sub-agent is best suited for the task
            3. Delegate the work to that agent
            4. Return the generated content
            
            Always provide clear, actionable content that follows best practices.
            """
        )
        
        # Store sub-agents for delegation
        self.sub_agents = {
            "email": email_agent,
            "social": social_agent,
            "blog": blog_agent
        }

    async def process_query(self, query: str, session_id: str = None) -> Dict[str, Any]:
        """Process a query from the frontend and delegate to appropriate sub-agent"""
        
        try:
            # First, let the root agent analyze the query and determine the content type
            analysis_prompt = f"""
            Analyze this query and determine the best content type to handle it:
            Query: {query}
            
            Available content types:
            - email: For email campaigns, newsletters, marketing emails
            - social: For social media posts, social campaigns
            - blog: For long-form articles, whitepapers, blog posts
            
            Respond with ONLY the content type (email, social, or blog).
            """
            
            analysis_response = await self.agent.run(analysis_prompt)
            content_type = analysis_response.text.strip().lower()
            
            # Validate content type
            if content_type not in self.sub_agents:
                content_type = "email"  # Default fallback
            
            # Delegate to the appropriate sub-agent
            if content_type == "email":
                result = await self.sub_agents["email"].generate_email_content(query)
            elif content_type == "social":
                result = await self.sub_agents["social"].generate_social_content(query)
            elif content_type == "blog":
                result = await self.sub_agents["blog"].generate_blog_content(query)
            
            # Add delegation info to result
            result["delegated_to"] = f"{content_type}_agent"
            result["session_id"] = session_id
            
            return result
            
        except Exception as e:
            return {
                "content_type": "unknown",
                "prompt": query,
                "error": str(e),
                "timestamp": get_current_time(),
                "status": "error",
                "session_id": session_id
            } 