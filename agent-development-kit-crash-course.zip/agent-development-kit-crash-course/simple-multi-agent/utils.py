import os
import json
import redis
from typing import Dict, Any, Optional
from datetime import datetime, timedelta

class RedisSessionService:
    def __init__(self, redis_url: str = None):
        self.redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        self.redis_client = redis.from_url(self.redis_url)
        self.session_ttl = 3600  # 1 hour

    def create_session(self, session_id: str, initial_data: Dict[str, Any] = None) -> bool:
        """Create a new session with initial data"""
        try:
            session_data = {
                "created_at": datetime.now().isoformat(),
                "last_updated": datetime.now().isoformat(),
                "data": initial_data or {}
            }
            self.redis_client.setex(
                f"session:{session_id}",
                self.session_ttl,
                json.dumps(session_data)
            )
            return True
        except Exception as e:
            print(f"Error creating session: {e}")
            return False

    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session data"""
        try:
            session_data = self.redis_client.get(f"session:{session_id}")
            if session_data:
                return json.loads(session_data)
            return None
        except Exception as e:
            print(f"Error getting session: {e}")
            return None

    def update_session(self, session_id: str, data: Dict[str, Any]) -> bool:
        """Update session data"""
        try:
            session = self.get_session(session_id)
            if session:
                session["data"].update(data)
                session["last_updated"] = datetime.now().isoformat()
                self.redis_client.setex(
                    f"session:{session_id}",
                    self.session_ttl,
                    json.dumps(session)
                )
                return True
            return False
        except Exception as e:
            print(f"Error updating session: {e}")
            return False

    def delete_session(self, session_id: str) -> bool:
        """Delete a session"""
        try:
            return bool(self.redis_client.delete(f"session:{session_id}"))
        except Exception as e:
            print(f"Error deleting session: {e}")
            return False

    def add_content_to_session(self, session_id: str, content_type: str, content: Dict[str, Any]) -> bool:
        """Add generated content to session"""
        try:
            session = self.get_session(session_id)
            if session:
                if "content" not in session["data"]:
                    session["data"]["content"] = {}
                session["data"]["content"][content_type] = content
                session["last_updated"] = datetime.now().isoformat()
                self.redis_client.setex(
                    f"session:{session_id}",
                    self.session_ttl,
                    json.dumps(session)
                )
                return True
            return False
        except Exception as e:
            print(f"Error adding content to session: {e}")
            return False

def get_current_time() -> str:
    """Get current time as a formatted string"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def get_formatted_time(format_type: str = "standard") -> str:
    """Get formatted time based on type"""
    now = datetime.now()
    if format_type == "iso":
        return now.isoformat()
    elif format_type == "short":
        return now.strftime("%m/%d/%Y %H:%M")
    elif format_type == "long":
        return now.strftime("%A, %B %d, %Y at %I:%M %p")
    else:
        return now.strftime("%Y-%m-%d %H:%M:%S") 