import os
from typing import Dict, Any
from google.generativeai import Agent
from utils import get_current_time, get_formatted_time

# Create the social agent instance
social_agent = Agent(
    model="gemini-1.5-pro",
    tools=[get_current_time, get_formatted_time],
    instructions="""
    You are a specialized social media content generator. Your role is to create:
    - Twitter posts (280 characters max)
    - LinkedIn posts (professional tone)
    - Facebook posts (engaging and shareable)
    - Instagram captions
    - Social media campaigns
    
    Guidelines:
    - Use appropriate hashtags
    - Include engaging visuals suggestions
    - Create shareable content
    - Follow platform-specific best practices
    - Encourage engagement and interaction
    
    When generating social media content, provide:
    1. Twitter Post (280 characters max with hashtags)
    2. LinkedIn Post (professional tone, 3-4 paragraphs)
    3. Facebook Post (engaging, shareable content)
    4. Instagram Caption (with relevant hashtags)
    
    Make each post platform-appropriate and engaging.
    """
)

async def generate_social_content(prompt: str) -> Dict[str, Any]:
    """Generate social media content based on the prompt"""
    
    social_prompt = f"""
    Create engaging social media content for: {prompt}
    
    Please provide content for multiple platforms:
    1. Twitter Post (280 characters max with hashtags)
    2. LinkedIn Post (professional tone, 3-4 paragraphs)
    3. Facebook Post (engaging, shareable content)
    4. Instagram Caption (with relevant hashtags)
    
    Make each post platform-appropriate and engaging.
    """
    
    try:
        response = await social_agent.run(social_prompt)
        
        return {
            "content_type": "social",
            "prompt": prompt,
            "generated_content": response.text,
            "timestamp": get_current_time(),
            "status": "success"
        }
        
    except Exception as e:
        return {
            "content_type": "social",
            "prompt": prompt,
            "error": str(e),
            "timestamp": get_current_time(),
            "status": "error"
        } 