import os
from typing import Dict, Any
from google.generativeai import Agent
from utils import get_current_time, get_formatted_time

# Create the blog agent instance
blog_agent = Agent(
    model="gemini-1.5-pro",
    tools=[get_current_time, get_formatted_time],
    instructions="""
    You are a specialized blog and long-form content generator. Your role is to create:
    - Blog articles
    - Whitepapers
    - Case studies
    - Thought leadership pieces
    - Technical documentation
    
    Guidelines:
    - Create comprehensive, well-structured content
    - Include proper headings and subheadings
    - Use engaging introductions and conclusions
    - Include relevant examples and data
    - Optimize for SEO when appropriate
    - Target 800-1500 words for blog posts
    
    When generating blog content, provide:
    1. Compelling Title
    2. Introduction (hook the reader)
    3. Main Content (with proper headings and subheadings)
    4. Key Takeaways/Summary
    5. Call-to-Action
    6. Suggested Meta Description for SEO
    
    Structure the content with:
    - Clear headings (H1, H2, H3)
    - Engaging paragraphs
    - Bullet points where appropriate
    - Professional tone
    - Actionable insights
    
    Target length: 800-1500 words
    """
)

async def generate_blog_content(prompt: str) -> Dict[str, Any]:
    """Generate blog content based on the prompt"""
    
    blog_prompt = f"""
    Create comprehensive blog content for: {prompt}
    
    Please provide:
    1. Compelling Title
    2. Introduction (hook the reader)
    3. Main Content (with proper headings and subheadings)
    4. Key Takeaways/Summary
    5. Call-to-Action
    6. Suggested Meta Description for SEO
    
    Structure the content with:
    - Clear headings (H1, H2, H3)
    - Engaging paragraphs
    - Bullet points where appropriate
    - Professional tone
    - Actionable insights
    
    Target length: 800-1500 words
    """
    
    try:
        response = await blog_agent.run(blog_prompt)
        
        return {
            "content_type": "blog",
            "prompt": prompt,
            "generated_content": response.text,
            "timestamp": get_current_time(),
            "status": "success"
        }
        
    except Exception as e:
        return {
            "content_type": "blog",
            "prompt": prompt,
            "error": str(e),
            "timestamp": get_current_time(),
            "status": "error"
        } 