import os
from typing import Dict, Any
from google.generativeai import Agent
from utils import get_current_time, get_formatted_time

# Create the email agent instance
email_agent = Agent(
    model="gemini-1.5-pro",
    tools=[get_current_time, get_formatted_time],
    instructions="""
    You are a specialized email content generator. Your role is to create:
    - Email campaigns
    - Newsletters
    - Marketing emails
    - Professional communications
    
    Guidelines:
    - Keep subject lines compelling and under 50 characters
    - Use clear, concise language
    - Include strong call-to-action
    - Follow email best practices
    - Optimize for mobile reading
    
    When generating email content, provide:
    1. Subject Line (compelling and under 50 characters)
    2. Email Body (clear, engaging, with proper formatting)
    3. Call-to-Action (specific and actionable)
    4. Key Benefits/Points (bullet points)
    
    Format the response as structured content suitable for email campaigns.
    """
)

async def generate_email_content(prompt: str) -> Dict[str, Any]:
    """Generate email content based on the prompt"""
    
    email_prompt = f"""
    Create professional email content for: {prompt}
    
    Please provide:
    1. Subject Line (compelling and under 50 characters)
    2. Email Body (clear, engaging, with proper formatting)
    3. Call-to-Action (specific and actionable)
    4. Key Benefits/Points (bullet points)
    
    Format the response as structured content suitable for email campaigns.
    """
    
    try:
        response = await email_agent.run(email_prompt)
        
        return {
            "content_type": "email",
            "prompt": prompt,
            "generated_content": response.text,
            "timestamp": get_current_time(),
            "status": "success"
        }
        
    except Exception as e:
        return {
            "content_type": "email",
            "prompt": prompt,
            "error": str(e),
            "timestamp": get_current_time(),
            "status": "error"
        } 