# Simple Multi-Agent System with FastAPI

A straightforward multi-agent system using Google Agent Development Kit (ADK) with a FastAPI REST API endpoint. The system follows a delegation pattern where a root agent analyzes queries and delegates to specialized sub-agents.

## Architecture

- **Root Agent**: Analyzes incoming queries and determines the appropriate content type, then delegates to specialized sub-agents
- **Email Agent**: Generates email content (campaigns, newsletters, marketing emails)
- **Social Agent**: Creates social media posts (Twitter, LinkedIn, Facebook, Instagram)
- **Blog Agent**: Writes long-form content (blog articles, whitepapers, case studies)
- **FastAPI Endpoint**: REST API for content generation
- **Session Management**: Redis-based session storage

## Workflow

1. Frontend sends a query to the API
2. Root agent analyzes the query context and intent
3. Root agent determines the best content type (email, social, or blog)
4. Root agent delegates the task to the appropriate specialized sub-agent
5. Sub-agent generates the content and returns it
6. Response includes the generated content and delegation information

## Quick Start

1. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Set environment variables**:
   ```bash
   export GOOGLE_API_KEY="your-gemini-api-key"
   export REDIS_URL="redis://localhost:6379"
   ```

3. **Start the FastAPI server**:
   ```bash
   python main.py
   ```

4. **Test the API**:
   ```bash
   python test_api.py
   ```

## API Endpoints

- `POST /generate-content`: Generate content using the multi-agent system
- `GET /health`: Health check endpoint
- `GET /sessions/{session_id}`: Get session data
- `DELETE /sessions/{session_id}`: Delete session
- `GET /agents`: List available agents and their capabilities

## Usage Example

```bash
curl -X POST "http://localhost:8000/generate-content" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Create content about 5G technology benefits",
    "session_id": "user123"
  }'
```

**Response Example**:
```json
{
  "content_type": "email",
  "prompt": "Create content about 5G technology benefits",
  "generated_content": "Subject: Unlock the Power of 5G Technology...",
  "timestamp": "2024-01-15 10:30:00",
  "status": "success",
  "delegated_to": "email_agent",
  "session_id": "user123"
}
```

## Project Structure

```
simple-multi-agent/
├── main.py                 # FastAPI server
├── test_api.py            # API test script
├── requirements.txt       # Dependencies
├── README.md             # This file
├── utils.py              # Utility functions and Redis session service
├── root_agent/
│   ├── __init__.py
│   └── agent.py          # Main coordinator agent
└── sub_agents/
    ├── __init__.py
    ├── email_agent/
    │   ├── __init__.py
    │   └── agent.py      # Email content agent
    ├── social_agent/
    │   ├── __init__.py
    │   └── agent.py      # Social media agent
    └── blog_agent/
        ├── __init__.py
        └── agent.py      # Blog content agent
```

## Agent Capabilities

### Root Agent
- Query analysis and context understanding
- Content type determination
- Sub-agent delegation
- Workflow coordination

### Email Agent
- Email campaigns
- Newsletters
- Marketing emails
- Professional communications

### Social Agent
- Twitter posts (280 characters max)
- LinkedIn posts (professional tone)
- Facebook posts (engaging content)
- Instagram captions
- Social media campaigns

### Blog Agent
- Blog articles
- Whitepapers
- Case studies
- Technical documentation
- Thought leadership pieces

## Session Management

The system supports session-based content tracking:
- Each session can store multiple content pieces
- Content is organized by type (email, social, blog)
- Sessions have TTL for automatic cleanup
- Session data includes timestamps and metadata 