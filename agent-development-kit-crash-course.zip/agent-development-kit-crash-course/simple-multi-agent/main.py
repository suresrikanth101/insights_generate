import os
import asyncio
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv

from root_agent.agent import RootAgent
from utils import RedisSessionService

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Simple Multi-Agent Content Generation API",
    description="A FastAPI server for generating content using multiple AI agents",
    version="1.0.0"
)

# Initialize root agent (which manages sub-agents)
root_agent = RootAgent()

# Initialize Redis session service
session_service = RedisSessionService()

# Pydantic models for request/response
class ContentRequest(BaseModel):
    query: str
    session_id: Optional[str] = None

class ContentResponse(BaseModel):
    content_type: str
    prompt: str
    generated_content: str
    timestamp: str
    status: str
    delegated_to: Optional[str] = None
    session_id: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    agents: Dict[str, str]

@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Simple Multi-Agent Content Generation API",
        "version": "1.0.0",
        "description": "Root agent analyzes queries and delegates to specialized sub-agents",
        "endpoints": {
            "generate_content": "POST /generate-content",
            "health": "GET /health",
            "sessions": "GET /sessions/{session_id}",
            "delete_session": "DELETE /sessions/{session_id}"
        }
    }

@app.post("/generate-content", response_model=ContentResponse, tags=["Content Generation"])
async def generate_content(request: ContentRequest):
    """Generate content using the multi-agent system"""
    
    try:
        # Create or get session if session_id provided
        if request.session_id:
            session = session_service.get_session(request.session_id)
            if not session:
                session_service.create_session(request.session_id, {"queries": []})
        
        # Process query through root agent (which will delegate to appropriate sub-agent)
        result = await root_agent.process_query(request.query, request.session_id)
        
        # Add to session if session_id provided
        if request.session_id and result["status"] == "success":
            session_service.add_content_to_session(
                request.session_id, 
                result["content_type"], 
                result
            )
        
        return ContentResponse(**result)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Content generation failed: {str(e)}")

@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=get_current_time(),
        agents={
            "root_agent": "active",
            "email_agent": "active", 
            "social_agent": "active",
            "blog_agent": "active"
        }
    )

@app.get("/sessions/{session_id}", tags=["Sessions"])
async def get_session(session_id: str):
    """Get session data"""
    session = session_service.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session

@app.delete("/sessions/{session_id}", tags=["Sessions"])
async def delete_session(session_id: str):
    """Delete a session"""
    success = session_service.delete_session(session_id)
    if not success:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"message": "Session deleted successfully"}

@app.get("/agents", tags=["Agents"])
async def list_agents():
    """List available agents and their capabilities"""
    return {
        "agents": {
            "root_agent": {
                "description": "Content generation manager that analyzes queries and delegates to specialized agents",
                "capabilities": ["Query analysis", "Content type determination", "Sub-agent delegation"]
            },
            "email_agent": {
                "description": "Email content specialist",
                "capabilities": ["Email campaigns", "Newsletters", "Marketing emails", "Professional communications"]
            },
            "social_agent": {
                "description": "Social media content specialist", 
                "capabilities": ["Twitter posts", "LinkedIn posts", "Facebook posts", "Instagram captions", "Social campaigns"]
            },
            "blog_agent": {
                "description": "Long-form content specialist",
                "capabilities": ["Blog articles", "Whitepapers", "Case studies", "Technical documentation", "Thought leadership"]
            }
        },
        "workflow": "Root agent receives query → Analyzes context → Delegates to appropriate sub-agent → Returns generated content"
    }

if __name__ == "__main__":
    import uvicorn
    from utils import get_current_time
    
    # Check for required environment variables
    if not os.getenv("GOOGLE_API_KEY"):
        print("Warning: GOOGLE_API_KEY environment variable not set")
    
    if not os.getenv("REDIS_URL"):
        print("Warning: REDIS_URL environment variable not set, using default")
    
    # Run the server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 