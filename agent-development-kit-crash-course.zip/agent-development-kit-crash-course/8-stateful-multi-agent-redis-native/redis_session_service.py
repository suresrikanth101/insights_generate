import json
import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
import redis
from collections import namedtuple

# Create a named tuple for list_sessions response to match ADK's expected format
SessionList = namedtuple('SessionList', ['sessions'])

# Simple session object to match ADK's expected interface
class Session:
    """Simple session object that wraps Redis data."""
    def __init__(self, id: str, app_name: str, user_id: str, state: Dict[str, Any], 
                 created_at: datetime, updated_at: datetime):
        self.id = id
        self.app_name = app_name
        self.user_id = user_id
        self.state = state
        self.created_at = created_at
        self.updated_at = updated_at

class RedisSessionService:
    """
    Redis-based session service that wraps Redis's built-in data structures.
    
    This service uses Redis's native data structures:
    - Hash (HSET/HGET) for session data
    - Set (SADD/SMEMBERS) for user session lists
    - String (SET/GET) for metadata
    """
    
    def __init__(self, redis_url: str = "redis://localhost:6379/0", **redis_kwargs):
        """
        Initialize Redis session service.
        
        Args:
            redis_url: Redis connection URL (default: redis://localhost:6379/0)
            **redis_kwargs: Additional Redis client configuration
        """
        self.redis_client = redis.from_url(redis_url, decode_responses=True, **redis_kwargs)
        
        # Test the connection
        try:
            self.redis_client.ping()
            print("✓ Connected to Redis successfully")
        except redis.ConnectionError as e:
            print(f"✗ Failed to connect to Redis: {e}")
            raise
    
    def _get_session_hash_key(self, session_id: str) -> str:
        """Generate Redis hash key for session data."""
        return f"session:{session_id}"
    
    def _get_user_sessions_set_key(self, app_name: str, user_id: str) -> str:
        """Generate Redis set key for user's session list."""
        return f"user_sessions:{app_name}:{user_id}"
    
    def _get_session_metadata_key(self, session_id: str) -> str:
        """Generate Redis string key for session metadata."""
        return f"session_meta:{session_id}"
    
    def create_session(
        self, 
        app_name: str, 
        user_id: str, 
        session_id: Optional[str] = None, 
        state: Optional[Dict[str, Any]] = None
    ) -> Session:
        """
        Create a new session using Redis hash for state and string for metadata.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Optional session ID (generated if not provided)
            state: Initial session state
            
        Returns:
            Created session object
        """
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        if state is None:
            state = {}
        
        now = datetime.now()
        now_iso = now.isoformat()
        
        # Store session state as Redis hash (more efficient for nested data)
        session_hash_key = self._get_session_hash_key(session_id)
        if state:
            # Convert state to flat key-value pairs for Redis hash
            flat_state = self._flatten_dict(state, prefix="state")
            self.redis_client.hset(session_hash_key, mapping=flat_state)
        
        # Store metadata as Redis string (JSON for complex metadata)
        metadata = {
            'app_name': app_name,
            'user_id': user_id,
            'created_at': now_iso,
            'updated_at': now_iso
        }
        metadata_key = self._get_session_metadata_key(session_id)
        self.redis_client.set(metadata_key, json.dumps(metadata))
        
        # Add session to user's session set
        user_sessions_key = self._get_user_sessions_set_key(app_name, user_id)
        self.redis_client.sadd(user_sessions_key, session_id)
        
        print(f"✓ Created session {session_id} for user {user_id} in app {app_name}")
        return Session(session_id, app_name, user_id, state, now, now)
    
    def get_session(self, app_name: str, user_id: str, session_id: str) -> Session:
        """
        Get an existing session from Redis.
        
        Args:
            app_name: Application name
            user_id: User identifier
            session_id: Session identifier
            
        Returns:
            Session object
            
        Raises:
            ValueError: If session not found
        """
        # Get metadata
        metadata_key = self._get_session_metadata_key(session_id)
        metadata_json = self.redis_client.get(metadata_key)
        
        if not metadata_json:
            raise ValueError(f"Session {session_id} not found")
        
        metadata = json.loads(metadata_json)
        
        # Verify the session belongs to the specified user and app
        if metadata['user_id'] != user_id or metadata['app_name'] != app_name:
            raise ValueError(f"Session {session_id} does not belong to user {user_id} in app {app_name}")
        
        # Get session state from Redis hash
        session_hash_key = self._get_session_hash_key(session_id)
        flat_state = self.redis_client.hgetall(session_hash_key)
        
        # Convert flat state back to nested dictionary
        state = self._unflatten_dict(flat_state, prefix="state")
        
        # Parse timestamps
        created_at = datetime.fromisoformat(metadata['created_at'])
        updated_at = datetime.fromisoformat(metadata['updated_at'])
        
        return Session(
            session_id, 
            metadata['app_name'], 
            metadata['user_id'], 
            state, 
            created_at, 
            updated_at
        )
    
    def list_sessions(self, app_name: str, user_id: str) -> SessionList:
        """
        List all sessions for a user using Redis set.
        
        Args:
            app_name: Application name
            user_id: User identifier
            
        Returns:
            SessionList object containing list of sessions
        """
        user_sessions_key = self._get_user_sessions_set_key(app_name, user_id)
        session_ids = self.redis_client.smembers(user_sessions_key)
        
        sessions = []
        for session_id in session_ids:
            try:
                session = self.get_session(app_name, user_id, session_id)
                sessions.append(session)
            except ValueError:
                # Session might have been deleted, remove from user's session set
                self.redis_client.srem(user_sessions_key, session_id)
                continue
        
        # Sort sessions by creation date (newest first)
        sessions.sort(key=lambda s: s.created_at, reverse=True)
        
        return SessionList(sessions=sessions)
    
    def update_session_state(self, session_id: str, state: Dict[str, Any]) -> None:
        """
        Update session state using Redis hash operations.
        
        Args:
            session_id: Session identifier
            state: New session state
        """
        # Update state in Redis hash
        session_hash_key = self._get_session_hash_key(session_id)
        if state:
            flat_state = self._flatten_dict(state, prefix="state")
            self.redis_client.hset(session_hash_key, mapping=flat_state)
        
        # Update metadata timestamp
        metadata_key = self._get_session_metadata_key(session_id)
        metadata_json = self.redis_client.get(metadata_key)
        
        if metadata_json:
            metadata = json.loads(metadata_json)
            metadata['updated_at'] = datetime.now().isoformat()
            self.redis_client.set(metadata_key, json.dumps(metadata))
    
    def delete_session(self, session_id: str) -> None:
        """
        Delete a session using Redis operations.
        
        Args:
            session_id: Session identifier
        """
        # Get metadata to find app_name and user_id
        metadata_key = self._get_session_metadata_key(session_id)
        metadata_json = self.redis_client.get(metadata_key)
        
        if metadata_json:
            metadata = json.loads(metadata_json)
            app_name = metadata['app_name']
            user_id = metadata['user_id']
            
            # Remove from user's session set
            user_sessions_key = self._get_user_sessions_set_key(app_name, user_id)
            self.redis_client.srem(user_sessions_key, session_id)
        
        # Delete session data and metadata
        session_hash_key = self._get_session_hash_key(session_id)
        self.redis_client.delete(session_hash_key, metadata_key)
        print(f"✓ Deleted session {session_id}")
    
    def clear_all_sessions(self, app_name: str, user_id: str) -> None:
        """
        Clear all sessions for a user using Redis operations.
        
        Args:
            app_name: Application name
            user_id: User identifier
        """
        sessions = self.list_sessions(app_name, user_id)
        for session in sessions.sessions:
            self.delete_session(session.id)
        print(f"✓ Cleared all sessions for user {user_id} in app {app_name}")
    
    def _flatten_dict(self, d: Dict[str, Any], prefix: str = "") -> Dict[str, str]:
        """
        Flatten a nested dictionary for Redis hash storage.
        
        Args:
            d: Dictionary to flatten
            prefix: Key prefix
            
        Returns:
            Flattened dictionary with string values
        """
        flat = {}
        for key, value in d.items():
            full_key = f"{prefix}:{key}" if prefix else key
            
            if isinstance(value, dict):
                flat.update(self._flatten_dict(value, full_key))
            elif isinstance(value, list):
                flat[full_key] = json.dumps(value)
            else:
                flat[full_key] = str(value)
        
        return flat
    
    def _unflatten_dict(self, flat_dict: Dict[str, str], prefix: str = "") -> Dict[str, Any]:
        """
        Unflatten a dictionary from Redis hash storage.
        
        Args:
            flat_dict: Flattened dictionary from Redis
            prefix: Key prefix to remove
            
        Returns:
            Nested dictionary
        """
        result = {}
        prefix_len = len(prefix) + 1 if prefix else 0
        
        for key, value in flat_dict.items():
            if prefix and not key.startswith(f"{prefix}:"):
                continue
                
            # Remove prefix from key
            clean_key = key[prefix_len:] if prefix_len > 0 else key
            
            # Try to parse as JSON (for lists/dicts), otherwise use as string
            try:
                parsed_value = json.loads(value)
                result[clean_key] = parsed_value
            except (json.JSONDecodeError, TypeError):
                result[clean_key] = value
        
        return result
    
    def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on Redis connection.
        
        Returns:
            Dictionary with health status information
        """
        try:
            # Test basic operations
            self.redis_client.ping()
            info = self.redis_client.info()
            
            return {
                "status": "healthy",
                "redis_version": info.get("redis_version", "unknown"),
                "connected_clients": info.get("connected_clients", 0),
                "used_memory_human": info.get("used_memory_human", "unknown"),
                "uptime_in_seconds": info.get("uptime_in_seconds", 0)
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def get_redis_stats(self) -> Dict[str, Any]:
        """
        Get Redis statistics for monitoring.
        
        Returns:
            Dictionary with Redis statistics
        """
        try:
            info = self.redis_client.info()
            return {
                "total_connections_received": info.get("total_connections_received", 0),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0),
                "used_memory_human": info.get("used_memory_human", "unknown"),
                "connected_clients": info.get("connected_clients", 0),
                "uptime_in_seconds": info.get("uptime_in_seconds", 0)
            }
        except Exception as e:
            return {"error": str(e)} 