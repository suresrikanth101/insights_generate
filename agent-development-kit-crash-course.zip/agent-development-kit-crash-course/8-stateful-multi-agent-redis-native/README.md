# Stateful Multi-Agent with Redis-Native Implementation

This folder contains an improved version of the stateful multi-agent system that uses Redis's native data structures instead of custom data classes. This approach is more efficient and leverages Redis's built-in capabilities properly.

## What's Different?

### Original Implementation (8-stateful-multi-agent/)
- Uses `InMemorySessionService` (non-persistent)
- Stores everything as JSON strings
- Custom data classes for session management

### Redis-Native Implementation (This Folder)
- Uses `RedisSessionService` with Redis native structures
- **Hash (HSET/HGET)** for session state data
- **Set (SADD/SMEMBERS)** for user session lists  
- **String (SET/GET)** for metadata
- More efficient memory usage and faster operations

## Redis Data Structure Mapping

| **Data Type** | **Redis Structure** | **Key Pattern** | **Benefits** |
|---------------|-------------------|-----------------|--------------|
| Session State | Hash | `session:{session_id}` | Efficient nested data, partial updates |
| User Sessions | Set | `user_sessions:{app}:{user}` | Fast listing, membership checks |
| Metadata | String | `session_meta:{session_id}` | JSON serialization, atomic ops |

## Performance Benefits

✅ **Partial Updates**: Update specific fields without retrieving entire state  
✅ **Memory Efficiency**: Redis hash compression for nested data  
✅ **Atomic Operations**: Redis guarantees data consistency  
✅ **Fast Queries**: Direct Redis operations for session listing  
✅ **Scalability**: Redis native structures handle large datasets better  

## Example Redis Data Structure

```bash
# Session state as Redis hash
session:abc-123-def
├── state:user_name → "Brandon Hancock"
├── state:purchased_courses → "[{\"id\":\"course_1\",\"date\":\"2024-01-15\"}]"
├── state:interaction_history → "[\"Asked about course\",\"Purchased course\"]"
└── state:preferences:timezone → "UTC-5"

# Metadata as Redis string
session_meta:abc-123-def → {"app_name":"DemoApp","user_id":"user123","created_at":"2024-01-15T10:30:00"}

# User sessions as Redis set
user_sessions:DemoApp:user123 → {abc-123-def, def-456-ghi}
```

## Project Structure

```
8-stateful-multi-agent-redis-native/
│
├── customer_service_agent/         # Main agent package (same as original)
│   ├── __init__.py
│   ├── agent.py
│   └── sub_agents/
│       ├── course_support_agent/
│       ├── order_agent/
│       ├── policy_agent/
│       └── sales_agent/
│
├── redis_session_service.py        # Redis-native session service
├── main.py                         # Updated main with Redis persistence
├── utils.py                        # Helper functions (same as original)
├── test_redis_native.py            # Test script for Redis-native features
├── redis_demo.py                   # Demonstration of Redis structures
├── .env                            # Environment variables
└── README.md                       # This documentation
```

## Getting Started

### Prerequisites

- Python 3.9+
- Google API Key for Gemini models
- Redis server (local or remote)

### Setup

1. **Install and start Redis**:
   ```bash
   # macOS
   brew install redis && brew services start redis
   
   # Linux
   sudo apt install redis-server && sudo systemctl start redis-server
   
   # Test connection
   redis-cli ping  # Should return: PONG
   ```

2. **Install dependencies**:
   ```bash
   pip install redis
   ```

3. **Set up environment**:
   ```bash
   cp .env.example .env
   # Add your GOOGLE_API_KEY to .env
   ```

### Running the Examples

1. **Test Redis-native features**:
   ```bash
   python test_redis_native.py
   ```

2. **See Redis data structures in action**:
   ```bash
   python redis_demo.py
   ```

3. **Run the main application**:
   ```bash
   python main.py
   ```

## Key Features

### 1. Efficient State Storage
```python
# Session state stored as Redis hash
session_hash_key = f"session:{session_id}"
redis_client.hset(session_hash_key, mapping={
    "state:user_name": "Brandon Hancock",
    "state:preferences:timezone": "UTC-5"
})
```

### 2. Partial Updates
```python
# Update only specific fields without retrieving entire state
redis_client.hset(f"session:{session_id}", "state:user_name", "Updated Name")
```

### 3. Fast Session Listing
```python
# Use Redis set for fast membership checks
user_sessions_key = f"user_sessions:{app_name}:{user_id}"
session_ids = redis_client.smembers(user_sessions_key)
```

### 4. Memory Monitoring
```python
# Get Redis statistics for monitoring
stats = session_service.get_redis_stats()
print(f"Memory used: {stats['used_memory_human']}")
```

## Comparison with Original

| Feature | Original | Redis-Native |
|---------|----------|--------------|
| **Persistence** | In-memory only | Redis persistent |
| **Data Structure** | JSON strings | Native Redis types |
| **Partial Updates** | Full state retrieval | Direct field updates |
| **Memory Usage** | Higher | More efficient |
| **Performance** | Good | Excellent |
| **Scalability** | Limited | High |

## Production Considerations

1. **Redis Configuration**: Use authentication, TLS, and persistence
2. **Monitoring**: Monitor Redis memory usage and performance
3. **Backup**: Implement Redis data backups
4. **Clustering**: Use Redis clusters for high availability

## Additional Resources

- [Redis Documentation](https://redis.io/docs/)
- [Redis Python Client](https://redis-py.readthedocs.io/)
- [Redis Data Types](https://redis.io/docs/data-types/) 