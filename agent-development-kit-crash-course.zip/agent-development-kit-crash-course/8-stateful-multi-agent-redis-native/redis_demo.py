#!/usr/bin/env python3
"""
Demonstration script showing Redis-native session service benefits.
This script shows how Redis's built-in data structures are used efficiently.
"""

import redis
from redis_session_service import RedisSessionService

def demonstrate_redis_structures():
    """Demonstrate how Redis data structures are used in the session service."""
    print("🔍 Redis Data Structure Demonstration")
    print("=" * 50)
    
    # Initialize Redis session service
    redis_url = "redis://localhost:6379/0"
    session_service = RedisSessionService(redis_url=redis_url)
    
    # Create a test session with complex state
    test_state = {
        "user_name": "Demo User",
        "purchased_courses": [
            {"id": "course_1", "purchase_date": "2024-01-15", "price": 99.99},
            {"id": "course_2", "purchase_date": "2024-01-16", "price": 149.99}
        ],
        "interaction_history": [
            "Asked about course content",
            "Purchased first course",
            "Asked about refund policy"
        ],
        "preferences": {
            "notification_email": True,
            "marketing_emails": False,
            "timezone": "UTC-5"
        }
    }
    
    print("\n1. Creating session with complex state...")
    session = session_service.create_session(
        app_name="DemoApp",
        user_id="demo_user",
        state=test_state
    )
    print(f"   ✓ Session created: {session.id}")
    
    # Show Redis data structures
    print("\n2. Examining Redis data structures...")
    
    # Get the raw Redis client to inspect data
    redis_client = session_service.redis_client
    
    # Show session hash (state data)
    session_hash_key = f"session:{session.id}"
    print(f"\n   📊 Session Hash (session:{session.id}):")
    hash_data = redis_client.hgetall(session_hash_key)
    for key, value in hash_data.items():
        print(f"      {key}: {value[:50]}{'...' if len(value) > 50 else ''}")
    
    # Show metadata string
    metadata_key = f"session_meta:{session.id}"
    print(f"\n   📋 Metadata String (session_meta:{session.id}):")
    metadata = redis_client.get(metadata_key)
    print(f"      {metadata}")
    
    # Show user sessions set
    user_sessions_key = "user_sessions:DemoApp:demo_user"
    print(f"\n   📝 User Sessions Set ({user_sessions_key}):")
    sessions_set = redis_client.smembers(user_sessions_key)
    for session_id in sessions_set:
        print(f"      {session_id}")
    
    # Demonstrate Redis operations
    print("\n3. Demonstrating Redis operations...")
    
    # Show how we can directly access Redis data
    print(f"\n   🔍 Direct Redis access:")
    print(f"      Session exists: {redis_client.exists(session_hash_key)}")
    print(f"      Hash fields count: {redis_client.hlen(session_hash_key)}")
    print(f"      Set members count: {redis_client.scard(user_sessions_key)}")
    
    # Show memory efficiency
    print(f"\n   💾 Memory efficiency:")
    memory_info = redis_client.memory_usage(session_hash_key)
    metadata_memory = redis_client.memory_usage(metadata_key)
    print(f"      Session hash memory: {memory_info} bytes")
    print(f"      Metadata memory: {metadata_memory} bytes")
    
    # Demonstrate partial updates
    print("\n4. Demonstrating partial updates...")
    
    # Update only specific fields in the hash
    print(f"   🔄 Updating specific state fields...")
    redis_client.hset(session_hash_key, "state:user_name", "Updated Demo User")
    redis_client.hset(session_hash_key, "state:preferences:timezone", "UTC-8")
    
    # Show the updated data
    print(f"   📊 Updated session hash:")
    updated_hash = redis_client.hgetall(session_hash_key)
    for key, value in updated_hash.items():
        if "user_name" in key or "timezone" in key:
            print(f"      {key}: {value}")
    
    # Demonstrate Redis set operations
    print("\n5. Demonstrating Redis set operations...")
    
    # Add another session to the set
    session2 = session_service.create_session(
        app_name="DemoApp",
        user_id="demo_user",
        state={"user_name": "Another User"}
    )
    
    print(f"   📝 User sessions set after adding second session:")
    updated_sessions = redis_client.smembers(user_sessions_key)
    for session_id in updated_sessions:
        print(f"      {session_id}")
    
    print(f"   📊 Set operations:")
    print(f"      Total sessions: {redis_client.scard(user_sessions_key)}")
    print(f"      Contains session 1: {redis_client.sismember(user_sessions_key, session.id)}")
    print(f"      Contains session 2: {redis_client.sismember(user_sessions_key, session2.id)}")
    
    # Cleanup
    print("\n6. Cleaning up...")
    session_service.delete_session(session.id)
    session_service.delete_session(session2.id)
    print("   ✓ Demo sessions cleaned up")
    
    print("\n🎯 Redis Native Benefits Demonstrated:")
    print("   ✅ Hash for efficient nested data storage")
    print("   ✅ Set for fast session listing and membership checks")
    print("   ✅ String for metadata with JSON serialization")
    print("   ✅ Partial updates without full data retrieval")
    print("   ✅ Memory efficient storage")
    print("   ✅ Atomic operations for data consistency")

if __name__ == "__main__":
    try:
        demonstrate_redis_structures()
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("Make sure Redis is running: redis-cli ping") 