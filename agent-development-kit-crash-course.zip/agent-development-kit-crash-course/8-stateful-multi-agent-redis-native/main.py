import asyncio

# Import the main customer service agent
from customer_service_agent.agent import customer_service_agent
from dotenv import load_dotenv
from google.adk.runners import Runner
from utils import add_user_query_to_history, call_agent_async
from redis_session_service import RedisSessionService

load_dotenv()

# ===== PART 1: Initialize Redis Session Service =====
# Using Redis cache for persistent storage with native data structures
redis_url = "redis://localhost:6379/0"
session_service = RedisSessionService(redis_url=redis_url)


# ===== PART 2: Define Initial State =====
# This will be used when creating a new session
initial_state = {
    "user_name": "Brandon Hancock",
    "purchased_courses": [],
    "interaction_history": [],
}


async def main_async():
    # Setup constants
    APP_NAME = "Customer Support"
    USER_ID = "aiwithbrandon"

    # ===== PART 3: Session Management - Find or Create =====
    # Check for existing sessions for this user
    existing_sessions = session_service.list_sessions(
        app_name=APP_NAME,
        user_id=USER_ID,
    )

    # If there's an existing session, use it, otherwise create a new one
    if existing_sessions and len(existing_sessions.sessions) > 0:
        # Use the most recent session
        SESSION_ID = existing_sessions.sessions[0].id
        print(f"Continuing existing session: {SESSION_ID}")
        
        # Show current state
        current_session = session_service.get_session(APP_NAME, USER_ID, SESSION_ID)
        print(f"Current user: {current_session.state.get('user_name', 'Unknown')}")
        print(f"Purchased courses: {len(current_session.state.get('purchased_courses', []))}")
        print(f"Interaction history: {len(current_session.state.get('interaction_history', []))} entries")
    else:
        # Create a new session with initial state
        new_session = session_service.create_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            state=initial_state,
        )
        SESSION_ID = new_session.id
        print(f"Created new session: {SESSION_ID}")

    # ===== PART 4: Agent Runner Setup =====
    # Create a runner with the main customer service agent
    runner = Runner(
        agent=customer_service_agent,
        app_name=APP_NAME,
        session_service=session_service,
    )

    # ===== PART 5: Interactive Conversation Loop =====
    print("\nWelcome to Customer Service Chat!")
    print("Your data will be persisted in Redis cache across application restarts.")
    print("Type 'exit' or 'quit' to end the conversation.")
    print("Type 'stats' to see Redis statistics.\n")

    while True:
        # Get user input
        user_input = input("You: ")

        # Check if user wants to exit
        if user_input.lower() in ["exit", "quit"]:
            print("Ending conversation. Your data has been saved to Redis cache.")
            break
        
        # Check if user wants to see Redis stats
        if user_input.lower() == "stats":
            stats = session_service.get_redis_stats()
            print(f"\n📊 Redis Statistics:")
            print(f"   Commands processed: {stats.get('total_commands_processed', 0)}")
            print(f"   Memory used: {stats.get('used_memory_human', 'unknown')}")
            print(f"   Connected clients: {stats.get('connected_clients', 0)}")
            print(f"   Uptime: {stats.get('uptime_in_seconds', 0)} seconds")
            continue

        # Update interaction history with the user's query
        add_user_query_to_history(
            session_service, APP_NAME, USER_ID, SESSION_ID, user_input
        )

        # Process the user query through the agent
        await call_agent_async(runner, USER_ID, SESSION_ID, user_input)

    # ===== PART 6: State Examination =====
    # Show final session state
    final_session = session_service.get_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID
    )
    print("\nFinal Session State:")
    for key, value in final_session.state.items():
        if isinstance(value, list):
            print(f"{key}: {len(value)} items")
        else:
            print(f"{key}: {value}")


def main():
    """Entry point for the application."""
    asyncio.run(main_async())


if __name__ == "__main__":
    main() 