#!/usr/bin/env python3
"""
Redis Native Features Demo
Demonstrates the benefits of using Redis native data structures vs custom serialization.
"""

import time
import json
from redis_native_wrapper import RedisNativeSessionWrapper

def demo_redis_native_features():
    """Demonstrate Redis native features for session management."""
    
    print("🚀 Redis Native Features Demo")
    print("=" * 50)
    
    # Initialize wrapper
    wrapper = RedisNativeSessionWrapper()
    
    # Demo 1: Basic Session Operations
    print("\n📝 Demo 1: Basic Session Operations")
    print("-" * 30)
    
    session_id = "demo_session_001"
    user_id = "user_123"
    
    # Create session with Redis Hash
    success = wrapper.create_session(session_id, user_id, {
        "agent_state": "active",
        "conversation_count": 0,
        "preferences": {"language": "en", "theme": "dark"}
    })
    print(f"✅ Session created: {success}")
    
    # Get session data (uses Redis HGETALL)
    session_data = wrapper.get_session(session_id)
    print(f"📊 Session data: {json.dumps(session_data, indent=2)}")
    
    # Demo 2: Atomic Operations
    print("\n⚡ Demo 2: Atomic Operations")
    print("-" * 30)
    
    # Update session atomically (Redis HSET)
    wrapper.update_session(session_id, {"conversation_count": 5})
    
    # Get updated data
    updated_data = wrapper.get_session(session_id)
    print(f"🔄 Updated conversation count: {updated_data.get('conversation_count')}")
    
    # Demo 3: TTL and Expiration
    print("\n⏰ Demo 3: TTL and Expiration")
    print("-" * 30)
    
    # Create session with short TTL
    short_session = "short_session_001"
    wrapper.create_session(short_session, user_id, {"test": "data"})
    
    # Set short TTL (10 seconds)
    wrapper.extend_session(short_session, 10)
    
    ttl = wrapper.get_session_ttl(short_session)
    print(f"⏱️  TTL for short session: {ttl} seconds")
    
    # Demo 4: User Session Management
    print("\n👤 Demo 4: User Session Management")
    print("-" * 30)
    
    # Create multiple sessions for same user
    for i in range(3):
        wrapper.create_session(f"user_session_{i}", user_id, {"session_num": i})
    
    # Get all sessions for user (uses Redis SMEMBERS)
    user_sessions = wrapper.get_user_sessions(user_id)
    print(f"📋 User sessions: {user_sessions}")
    
    # Demo 5: Performance Comparison
    print("\n⚡ Demo 5: Performance Comparison")
    print("-" * 30)
    
    # Test Redis native operations speed
    start_time = time.time()
    
    for i in range(100):
        test_session = f"perf_test_{i}"
        wrapper.create_session(test_session, f"user_{i}", {"data": f"value_{i}"})
        wrapper.get_session(test_session)
        wrapper.update_session(test_session, {"updated": True})
    
    redis_time = time.time() - start_time
    print(f"⏱️  Redis native operations (100 sessions): {redis_time:.4f} seconds")
    
    # Demo 6: Redis Statistics
    print("\n📊 Demo 6: Redis Statistics")
    print("-" * 30)
    
    stats = wrapper.get_redis_stats()
    print(f"🔗 Connected clients: {stats.get('connected_clients')}")
    print(f"💾 Memory used: {stats.get('used_memory_human')}")
    print(f"📈 Commands processed: {stats.get('total_commands_processed')}")
    print(f"🎯 Cache hits: {stats.get('keyspace_hits')}")
    print(f"❌ Cache misses: {stats.get('keyspace_misses')}")
    
    # Demo 7: Cleanup
    print("\n🧹 Demo 7: Cleanup")
    print("-" * 30)
    
    # Delete test sessions
    for i in range(100):
        wrapper.delete_session(f"perf_test_{i}")
    
    # Delete demo sessions
    wrapper.delete_session(session_id)
    wrapper.delete_session(short_session)
    for i in range(3):
        wrapper.delete_session(f"user_session_{i}")
    
    print("✅ All test sessions cleaned up")
    
    print("\n🎉 Demo completed!")
    print("\n💡 Benefits of Redis Native Features:")
    print("   • Atomic operations (thread-safe)")
    print("   • Built-in TTL for automatic expiration")
    print("   • Rich data structures (Hashes, Sets)")
    print("   • No custom serialization needed")
    print("   • Better performance than custom code")
    print("   • Built-in monitoring and statistics")

def demo_redis_commands():
    """Show the actual Redis commands being used."""
    
    print("\n🔧 Redis Commands Used")
    print("=" * 30)
    
    commands = {
        "Session Creation": [
            "HSET session:{id} field1 value1 field2 value2...",
            "EXPIRE session:{id} ttl_seconds",
            "SADD user_sessions:{user_id} session_id"
        ],
        "Session Retrieval": [
            "HGETALL session:{id}",
            "HSET session:{id} last_accessed timestamp",
            "EXPIRE session:{id} ttl_seconds"
        ],
        "Session Update": [
            "HSET session:{id} field value...",
            "EXPIRE session:{id} ttl_seconds"
        ],
        "Session Deletion": [
            "DEL session:{id}",
            "SREM user_sessions:{user_id} session_id"
        ],
        "User Sessions": [
            "SMEMBERS user_sessions:{user_id}"
        ],
        "Session Check": [
            "EXISTS session:{id}"
        ],
        "TTL Management": [
            "TTL session:{id}",
            "EXPIRE session:{id} new_ttl"
        ]
    }
    
    for operation, cmds in commands.items():
        print(f"\n{operation}:")
        for cmd in cmds:
            print(f"  • {cmd}")

if __name__ == "__main__":
    try:
        demo_redis_native_features()
        demo_redis_commands()
    except Exception as e:
        print(f"❌ Error: {e}")
        print("Make sure Redis is running: redis-server") 