#!/usr/bin/env python3
"""
Test script to verify Redis-native session service functionality.
This script tests the Redis-native implementation with native data structures.
"""

import json
from redis_session_service import RedisSessionService

def test_redis_native_features():
    """Test Redis-native session service with advanced features."""
    print("🔧 Testing Redis-Native Session Service")
    print("=" * 50)
    
    try:
        # Initialize Redis session service
        redis_url = "redis://localhost:6379/0"
        session_service = RedisSessionService(redis_url=redis_url)
        
        # Test 1: Health check
        print("\n1. Testing Redis health check...")
        health = session_service.health_check()
        print(f"   Status: {health['status']}")
        if health['status'] == 'healthy':
            print(f"   Redis Version: {health['redis_version']}")
            print(f"   Connected Clients: {health['connected_clients']}")
        else:
            print(f"   Error: {health['error']}")
            return False
        
        # Test 2: Create session with complex nested state
        print("\n2. Testing session creation with complex nested state...")
        complex_state = {
            "user_name": "Brandon Hancock",
            "purchased_courses": [
                {"id": "ai_marketing_platform", "purchase_date": "2024-01-15", "price": 149.99},
                {"id": "advanced_ai_course", "purchase_date": "2024-01-16", "price": 299.99}
            ],
            "interaction_history": [
                "Asked about course content",
                "Purchased AI Marketing Platform course",
                "Asked about refund policy"
            ],
            "preferences": {
                "notification_email": True,
                "marketing_emails": False,
                "timezone": "UTC-5",
                "language": "en"
            },
            "account_info": {
                "subscription_tier": "premium",
                "last_login": "2024-01-15T10:30:00",
                "login_count": 42
            }
        }
        
        session = session_service.create_session(
            app_name="Customer Support",
            user_id="aiwithbrandon",
            state=complex_state
        )
        print(f"   ✓ Created session: {session.id}")
        print(f"   User: {session.state.get('user_name')}")
        print(f"   Courses: {len(session.state.get('purchased_courses', []))}")
        print(f"   History: {len(session.state.get('interaction_history', []))} interactions")
        print(f"   Preferences: {len(session.state.get('preferences', {}))} settings")
        
        # Test 3: Test Redis native data structures
        print("\n3. Testing Redis native data structures...")
        redis_client = session_service.redis_client
        
        # Check session hash
        session_hash_key = f"session:{session.id}"
        hash_fields = redis_client.hlen(session_hash_key)
        print(f"   ✓ Session hash fields: {hash_fields}")
        
        # Check metadata string
        metadata_key = f"session_meta:{session.id}"
        metadata_exists = redis_client.exists(metadata_key)
        print(f"   ✓ Metadata exists: {metadata_exists}")
        
        # Check user sessions set
        user_sessions_key = "user_sessions:Customer Support:aiwithbrandon"
        set_members = redis_client.scard(user_sessions_key)
        print(f"   ✓ User sessions set members: {set_members}")
        
        # Test 4: Test partial updates using Redis hash
        print("\n4. Testing partial updates with Redis hash...")
        
        # Update only specific fields without retrieving entire state
        redis_client.hset(session_hash_key, "state:user_name", "Updated Brandon Hancock")
        redis_client.hset(session_hash_key, "state:preferences:timezone", "UTC-8")
        redis_client.hset(session_hash_key, "state:account_info:login_count", "43")
        
        print(f"   ✓ Updated specific fields in Redis hash")
        
        # Verify updates
        updated_session = session_service.get_session(
            app_name="Customer Support",
            user_id="aiwithbrandon",
            session_id=session.id
        )
        print(f"   Updated name: {updated_session.state.get('user_name')}")
        print(f"   Updated timezone: {updated_session.state.get('preferences', {}).get('timezone')}")
        print(f"   Updated login count: {updated_session.state.get('account_info', {}).get('login_count')}")
        
        # Test 5: Test memory efficiency
        print("\n5. Testing memory efficiency...")
        memory_usage = redis_client.memory_usage(session_hash_key)
        metadata_memory = redis_client.memory_usage(metadata_key)
        print(f"   Session hash memory: {memory_usage} bytes")
        print(f"   Metadata memory: {metadata_memory} bytes")
        print(f"   Total memory for session: {memory_usage + metadata_memory} bytes")
        
        # Test 6: Test Redis set operations
        print("\n6. Testing Redis set operations...")
        
        # Create another session
        session2 = session_service.create_session(
            app_name="Customer Support",
            user_id="aiwithbrandon",
            state={"user_name": "Another Session", "test": True}
        )
        
        # Check set operations
        total_sessions = redis_client.scard(user_sessions_key)
        contains_session1 = redis_client.sismember(user_sessions_key, session.id)
        contains_session2 = redis_client.sismember(user_sessions_key, session2.id)
        
        print(f"   Total sessions in set: {total_sessions}")
        print(f"   Contains session 1: {contains_session1}")
        print(f"   Contains session 2: {contains_session2}")
        
        # Test 7: Test session listing with Redis set
        print("\n7. Testing session listing with Redis set...")
        sessions_list = session_service.list_sessions(
            app_name="Customer Support",
            user_id="aiwithbrandon"
        )
        print(f"   ✓ Found {len(sessions_list.sessions)} sessions")
        
        # Sort by creation date
        for i, s in enumerate(sessions_list.sessions, 1):
            print(f"   Session {i}: {s.id} (created: {s.created_at.strftime('%Y-%m-%d %H:%M:%S')})")
        
        # Test 8: Test Redis statistics
        print("\n8. Testing Redis statistics...")
        stats = session_service.get_redis_stats()
        print(f"   Commands processed: {stats.get('total_commands_processed', 0)}")
        print(f"   Memory used: {stats.get('used_memory_human', 'unknown')}")
        print(f"   Keyspace hits: {stats.get('keyspace_hits', 0)}")
        print(f"   Keyspace misses: {stats.get('keyspace_misses', 0)}")
        
        # Test 9: Test session persistence simulation
        print("\n9. Testing session persistence simulation...")
        # Simulate application restart
        session_service2 = RedisSessionService(redis_url=redis_url)
        
        # Try to retrieve the same session
        persisted_session = session_service2.get_session(
            app_name="Customer Support",
            user_id="aiwithbrandon",
            session_id=session.id
        )
        print(f"   ✓ Retrieved persisted session: {persisted_session.id}")
        print(f"   User name persisted: {persisted_session.state.get('user_name')}")
        print(f"   Complex preferences persisted: {persisted_session.state.get('preferences', {})}")
        
        # Test 10: Test direct Redis operations
        print("\n10. Testing direct Redis operations...")
        
        # Get all hash fields
        all_hash_fields = redis_client.hgetall(session_hash_key)
        print(f"   Total hash fields: {len(all_hash_fields)}")
        
        # Get specific hash field
        user_name_field = redis_client.hget(session_hash_key, "state:user_name")
        print(f"   Direct hash get - user_name: {user_name_field}")
        
        # Check if hash field exists
        field_exists = redis_client.hexists(session_hash_key, "state:user_name")
        print(f"   Hash field exists: {field_exists}")
        
        # Test 11: Cleanup
        print("\n11. Testing cleanup...")
        session_service.delete_session(session.id)
        session_service.delete_session(session2.id)
        print("   ✓ Deleted test sessions")
        
        # Verify cleanup
        final_sessions = session_service.list_sessions("Customer Support", "aiwithbrandon")
        print(f"   Sessions after cleanup: {len(final_sessions.sessions)}")
        
        print("\n🎉 All Redis-native tests passed!")
        print("   ✅ Redis hash for efficient state storage")
        print("   ✅ Redis set for fast session listing")
        print("   ✅ Redis string for metadata")
        print("   ✅ Partial updates without full retrieval")
        print("   ✅ Memory efficient storage")
        print("   ✅ Direct Redis operations available")
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure Redis is running: redis-cli ping")
        print("2. Check Redis connection: redis-cli -h localhost -p 6379")
        print("3. Verify Redis URL in configuration")
        print("4. Install Redis dependency: pip install redis")
        return False

if __name__ == "__main__":
    success = test_redis_native_features()
    exit(0 if success else 1) 