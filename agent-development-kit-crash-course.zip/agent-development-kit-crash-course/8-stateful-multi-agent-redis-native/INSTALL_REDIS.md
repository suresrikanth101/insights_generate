# Redis Installation Guide

## Redis Open Source Installation

### Windows (Using WSL or Docker recommended)

#### Option 1: Docker (Recommended)
```bash
# Install Docker Desktop from https://www.docker.com/products/docker-desktop
# Then run:
docker run -d --name redis-server -p 6379:6379 redis:latest
```

#### Option 2: WSL2 + Ubuntu
```bash
# In WSL2 Ubuntu terminal:
sudo apt update
sudo apt install redis-server
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

#### Option 3: Windows Subsystem for Linux (WSL)
```bash
# Install WSL2 first, then:
wsl --install Ubuntu
# Then follow Ubuntu instructions above
```

### macOS
```bash
# Using Homebrew
brew install redis
brew services start redis

# Or using Docker
docker run -d --name redis-server -p 6379:6379 redis:latest
```

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install redis-server
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

### Linux (CentOS/RHEL)
```bash
sudo yum install redis
sudo systemctl start redis
sudo systemctl enable redis
```

## Verify Installation

```bash
# Test Redis connection
redis-cli ping
# Should return: PONG

# Check Redis info
redis-cli info server
```

## Python Redis Client

Install the Python Redis client:
```bash
pip install redis
```

## Quick Test

Run the demo to test your Redis installation:
```bash
cd 8-stateful-multi-agent-redis-native
python redis_native_demo.py
```

## Redis Configuration

### Default Configuration (Good for Development)
- Port: 6379
- No authentication (for local development)
- Memory limit: Based on available RAM
- Persistence: RDB snapshots enabled

### Custom Configuration (Optional)
Create `/etc/redis/redis.conf` or use Docker with custom config:
```bash
# Docker with custom config
docker run -d --name redis-server -p 6379:6379 \
  -v /path/to/redis.conf:/usr/local/etc/redis/redis.conf \
  redis:latest redis-server /usr/local/etc/redis/redis.conf
```

## Troubleshooting

### Common Issues:

1. **Connection Refused**
   ```bash
   # Check if Redis is running
   sudo systemctl status redis-server
   # or for Docker:
   docker ps | grep redis
   ```

2. **Port Already in Use**
   ```bash
   # Check what's using port 6379
   netstat -tulpn | grep 6379
   # Kill the process or use different port
   ```

3. **Permission Denied**
   ```bash
   # Make sure Redis has proper permissions
   sudo chown redis:redis /var/lib/redis
   sudo chmod 750 /var/lib/redis
   ```

## Redis CLI Commands

```bash
# Connect to Redis
redis-cli

# Basic commands
SET key value
GET key
DEL key
EXISTS key
TTL key
EXPIRE key seconds

# Hash operations
HSET hash field value
HGET hash field
HGETALL hash
HDEL hash field

# Set operations
SADD set member
SMEMBERS set
SREM set member

# List operations
LPUSH list value
RPOP list
LRANGE list start stop

# Server info
INFO
INFO memory
INFO clients
```

## Performance Tips

1. **Memory Management**
   ```bash
   # Set max memory (in redis.conf)
   maxmemory 256mb
   maxmemory-policy allkeys-lru
   ```

2. **Persistence Options**
   ```bash
   # RDB snapshots (default)
   save 900 1
   save 300 10
   save 60 10000
   
   # AOF (append-only file)
   appendonly yes
   appendfsync everysec
   ```

3. **Security (for production)**
   ```bash
   # Require authentication
   requirepass your_password
   
   # Bind to specific IP
   bind 127.0.0.1
   ``` 