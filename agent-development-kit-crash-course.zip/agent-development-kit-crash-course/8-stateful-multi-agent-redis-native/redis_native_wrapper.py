import redis
import json
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import logging

class RedisNativeSessionWrapper:
    """
    Simple wrapper around Redis native capabilities for session management.
    Uses Redis Hashes for session data, Sets for user sessions, and TTL for expiration.
    """
    
    def __init__(self, redis_url: str = "redis://localhost:6379", default_ttl: int = 3600):
        """
        Initialize Redis connection and wrapper.
        
        Args:
            redis_url: Redis connection URL
            default_ttl: Default session TTL in seconds (1 hour)
        """
        self.redis_client = redis.from_url(redis_url)
        self.default_ttl = default_ttl
        self.logger = logging.getLogger(__name__)
        
        # Test connection
        try:
            self.redis_client.ping()
            self.logger.info("Connected to Redis successfully")
        except Exception as e:
            self.logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    def create_session(self, session_id: str, user_id: str, initial_data: Dict[str, Any] = None) -> bool:
        """
        Create a new session using Redis Hash.
        
        Args:
            session_id: Unique session identifier
            user_id: User identifier
            initial_data: Initial session data
            
        Returns:
            bool: True if session created successfully
        """
        try:
            # Store session data in Redis Hash
            session_key = f"session:{session_id}"
            session_data = {
                "user_id": user_id,
                "created_at": datetime.now().isoformat(),
                "last_accessed": datetime.now().isoformat()
            }
            
            if initial_data:
                session_data.update(initial_data)
            
            # Use Redis Hash to store session data
            self.redis_client.hset(session_key, mapping=session_data)
            
            # Set TTL for automatic expiration
            self.redis_client.expire(session_key, self.default_ttl)
            
            # Add session to user's session list
            user_sessions_key = f"user_sessions:{user_id}"
            self.redis_client.sadd(user_sessions_key, session_id)
            
            self.logger.info(f"Created session {session_id} for user {user_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create session {session_id}: {e}")
            return False
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve session data using Redis Hash.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Dict containing session data or None if not found
        """
        try:
            session_key = f"session:{session_id}"
            
            # Get all session data from Redis Hash
            session_data = self.redis_client.hgetall(session_key)
            
            if not session_data:
                return None
            
            # Update last accessed time
            self.redis_client.hset(session_key, "last_accessed", datetime.now().isoformat())
            
            # Refresh TTL
            self.redis_client.expire(session_key, self.default_ttl)
            
            # Convert bytes to strings for JSON compatibility
            return {k.decode('utf-8') if isinstance(k, bytes) else k: 
                   v.decode('utf-8') if isinstance(v, bytes) else v 
                   for k, v in session_data.items()}
            
        except Exception as e:
            self.logger.error(f"Failed to get session {session_id}: {e}")
            return None
    
    def update_session(self, session_id: str, data: Dict[str, Any]) -> bool:
        """
        Update session data using Redis Hash.
        
        Args:
            session_id: Session identifier
            data: Data to update
            
        Returns:
            bool: True if updated successfully
        """
        try:
            session_key = f"session:{session_id}"
            
            # Update session data in Redis Hash
            self.redis_client.hset(session_key, mapping=data)
            
            # Update last accessed time
            self.redis_client.hset(session_key, "last_accessed", datetime.now().isoformat())
            
            # Refresh TTL
            self.redis_client.expire(session_key, self.default_ttl)
            
            self.logger.info(f"Updated session {session_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to update session {session_id}: {e}")
            return False
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete session using Redis DEL.
        
        Args:
            session_id: Session identifier
            
        Returns:
            bool: True if deleted successfully
        """
        try:
            session_key = f"session:{session_id}"
            
            # Get user_id before deleting
            user_id = self.redis_client.hget(session_key, "user_id")
            
            # Delete session
            self.redis_client.delete(session_key)
            
            # Remove from user's session list
            if user_id:
                user_sessions_key = f"user_sessions:{user_id.decode('utf-8')}"
                self.redis_client.srem(user_sessions_key, session_id)
            
            self.logger.info(f"Deleted session {session_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete session {session_id}: {e}")
            return False
    
    def get_user_sessions(self, user_id: str) -> List[str]:
        """
        Get all sessions for a user using Redis Set.
        
        Args:
            user_id: User identifier
            
        Returns:
            List of session IDs
        """
        try:
            user_sessions_key = f"user_sessions:{user_id}"
            sessions = self.redis_client.smembers(user_sessions_key)
            
            return [session.decode('utf-8') if isinstance(session, bytes) else session 
                   for session in sessions]
            
        except Exception as e:
            self.logger.error(f"Failed to get sessions for user {user_id}: {e}")
            return []
    
    def session_exists(self, session_id: str) -> bool:
        """
        Check if session exists using Redis EXISTS.
        
        Args:
            session_id: Session identifier
            
        Returns:
            bool: True if session exists
        """
        try:
            session_key = f"session:{session_id}"
            return bool(self.redis_client.exists(session_key))
            
        except Exception as e:
            self.logger.error(f"Failed to check session {session_id}: {e}")
            return False
    
    def get_session_ttl(self, session_id: str) -> int:
        """
        Get remaining TTL for session.
        
        Args:
            session_id: Session identifier
            
        Returns:
            int: Remaining TTL in seconds, -1 if no TTL, -2 if key doesn't exist
        """
        try:
            session_key = f"session:{session_id}"
            return self.redis_client.ttl(session_key)
            
        except Exception as e:
            self.logger.error(f"Failed to get TTL for session {session_id}: {e}")
            return -2
    
    def extend_session(self, session_id: str, ttl_seconds: int = None) -> bool:
        """
        Extend session TTL.
        
        Args:
            session_id: Session identifier
            ttl_seconds: New TTL in seconds (uses default if None)
            
        Returns:
            bool: True if extended successfully
        """
        try:
            session_key = f"session:{session_id}"
            ttl = ttl_seconds or self.default_ttl
            
            return bool(self.redis_client.expire(session_key, ttl))
            
        except Exception as e:
            self.logger.error(f"Failed to extend session {session_id}: {e}")
            return False
    
    def get_redis_stats(self) -> Dict[str, Any]:
        """
        Get Redis statistics for monitoring.
        
        Returns:
            Dict containing Redis stats
        """
        try:
            info = self.redis_client.info()
            return {
                "connected_clients": info.get("connected_clients", 0),
                "used_memory_human": info.get("used_memory_human", "0B"),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0)
            }
        except Exception as e:
            self.logger.error(f"Failed to get Redis stats: {e}")
            return {}

# Example usage
if __name__ == "__main__":
    # Initialize wrapper
    session_wrapper = RedisNativeSessionWrapper()
    
    # Create a session
    session_id = "test_session_123"
    user_id = "user_456"
    initial_data = {"agent_state": "active", "conversation_count": 0}
    
    success = session_wrapper.create_session(session_id, user_id, initial_data)
    print(f"Session created: {success}")
    
    # Get session data
    session_data = session_wrapper.get_session(session_id)
    print(f"Session data: {session_data}")
    
    # Update session
    session_wrapper.update_session(session_id, {"conversation_count": 5})
    
    # Get updated session
    updated_data = session_wrapper.get_session(session_id)
    print(f"Updated session: {updated_data}")
    
    # Get Redis stats
    stats = session_wrapper.get_redis_stats()
    print(f"Redis stats: {stats}") 