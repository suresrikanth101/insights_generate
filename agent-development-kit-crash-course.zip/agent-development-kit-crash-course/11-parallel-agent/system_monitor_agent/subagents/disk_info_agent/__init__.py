"""Disk info agent for system monitoring."""

from .agent import disk_info_agent
