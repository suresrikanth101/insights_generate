"""CPU info agent for system monitoring."""

from .agent import cpu_info_agent
