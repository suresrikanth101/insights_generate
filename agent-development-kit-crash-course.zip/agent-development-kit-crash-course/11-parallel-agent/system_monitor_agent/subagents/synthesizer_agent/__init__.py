"""System report synthesizer agent for system monitoring."""

from .agent import system_report_synthesizer
