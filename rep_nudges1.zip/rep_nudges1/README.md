# Rep Nudges LLM Generator

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Add your OpenAI API key to a `.env` file in the root directory:
   ```
   OPENAI_API_KEY=sk-...
   ```
3. Run the app:
   ```bash
   streamlit run app.py
   ```

## Usage
- Paste the rep's page details into the text area.
- Click 'Generate Rep Nudges' to get the LLM-generated response. 