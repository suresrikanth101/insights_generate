import streamlit as st
from utils.llm_utils import get_llm_response

# Load the base prompt from file
def load_base_prompt():
    with open("prompts/base_prompt.txt", "r", encoding="utf-8") as f:
        return f.read()

st.title("Rep Nudges LLM Generator")

page_details = st.text_area("Enter page details (paste from your source):", height=300)

if st.button("Generate Rep Nudges"):
    if not page_details.strip():
        st.warning("Please enter the page details.")
    else:
        base_prompt = load_base_prompt()
        full_prompt = base_prompt + page_details.strip() + "\n\nResponse:"
        response = get_llm_response(full_prompt)
        st.subheader("LLM Response:")
        st.write(response)

st.markdown("---")
st.markdown("**Instructions:** Paste the rep's page details above and click 'Generate Rep Nudges'.") 