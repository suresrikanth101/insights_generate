def main():
    print("Hello from vz-loop!")


if __name__ == "__main__":
    main()
