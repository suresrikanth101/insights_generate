# Web Scraper

A robust web scraping module that can process URLs from an Excel file and extract content from websites.

## Features

- Reads URLs from an Excel file
- Multi-threaded scraping for better performance
- Robust error handling and logging
- Rate limiting to be respectful to websites
- Saves scraped content to text files
- Extracts titles, text content, and links from web pages

## Requirements

- Python 3.7+
- Required packages listed in `requirements.txt`

## Installation

1. Clone this repository
2. Install the required packages:
```bash
pip install -r requirements.txt
```

## Usage

1. Prepare your Excel file (`urls.xlsx`) with a column named 'url' containing the URLs you want to scrape.

2. Run the scraper:
```bash
python web_scraper.py
```

The scraper will:
- Create a `scraped_data` directory to store the results
- Create a `scraper.log` file for logging
- Save individual text files for each scraped URL

## Output Format

For each URL, a text file will be created with the following format:
```
URL: [original URL]
Title: [page title]
Text Content: [main text content]
Links: [list of links found on the page]
```

## Error Handling

- The scraper includes comprehensive error handling
- Failed scrapes are logged in `scraper.log`
- The scraper continues running even if some URLs fail
- Rate limiting is implemented to avoid overwhelming servers

## Customization

You can modify the following parameters in the code:
- `max_workers`: Number of concurrent threads (default: 5)
- `output_dir`: Directory for saving scraped content (default: 'scraped_data')
- Delay between requests (currently 1-3 seconds)
