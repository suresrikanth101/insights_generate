import os
from datetime import datetime

def save_new_version(content, folder="versions"):
    os.makedirs(folder, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{folder}/content_{timestamp}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    return filename

def get_latest_version(folder="versions"):
    os.makedirs(folder, exist_ok=True)
    files = sorted(os.listdir(folder), reverse=True)
    if not files:
        return None, None
    latest = os.path.join(folder, files[0])
    with open(latest, "r", encoding="utf-8") as f:
        return files[0], f.read()

def content_has_changed(old, new):
    return old.strip() != new.strip()
