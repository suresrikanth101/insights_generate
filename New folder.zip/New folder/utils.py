import difflib

def get_diff_html(text1, text2):
    """
    Generates side-by-side HTML difference view using difflib
    """
    diff = difflib.HtmlDiff(tabsize=2, wrapcolumn=100)
    return diff.make_file(
        text1.splitlines(), 
        text2.splitlines(), 
        fromdesc="Previous Version", 
        todesc="Latest Version",
        context=True,
        numlines=5
    )
