import streamlit as st
from scraper import scrape_content, get_robots_info, is_allowed_by_robots
from version_manager import save_new_version, get_latest_version, content_has_changed
from utils import get_diff_html

st.set_page_config(page_title="Web Content Tracker", layout="wide")
st.title("🕸️ Web Content Management & Versioning")

url = st.text_input("Enter a web page URL to track:", placeholder="https://example.com")

if url:
    st.divider()

    # Show robots.txt rules
    st.subheader("🤖 robots.txt Rules")
    robots_url, allowed_paths, disallowed_paths = get_robots_info(url)
    st.write(f"Robots.txt URL: `{robots_url}`")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("✅ **Allowed Paths:**")
        st.code("\n".join(allowed_paths) if allowed_paths else "None listed")

    with col2:
        st.markdown("🚫 **Disallowed Paths:**")
        st.code("\n".join(disallowed_paths) if disallowed_paths else "None listed")

    st.divider()

    try:
        if not is_allowed_by_robots(url):
            st.error("⚠️ Scraping is not allowed for this URL according to robots.txt.")
        else:
            st.subheader("📄 Scraping & Versioning")
            current_content = scrape_content(url)
            latest_filename, latest_content = get_latest_version()

            if not latest_content:
                file = save_new_version(current_content)
                st.success(f"✅ First version saved: `{file}`")
            elif content_has_changed(latest_content, current_content):
                file = save_new_version(current_content)
                st.success(f"✅ Content changed. New version saved: `{file}`")
            else:
                st.info("ℹ️ No changes detected. Using latest version.")

            if latest_content and content_has_changed(latest_content, current_content):
                st.subheader("🔍 Difference Between Versions (Side-by-Side)")
                html_diff = get_diff_html(latest_content, current_content)
                st.components.v1.html(html_diff, height=800, scrolling=True)

    except Exception as e:
        st.error(f"❌ Error: {e}")
