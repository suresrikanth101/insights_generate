import requests
from bs4 import BeautifulSoup
from urllib.robotparser import RobotFileParser
from urllib.parse import urlparse


def is_allowed_by_robots(url):
    parsed_url = urlparse(url)
    robots_url = f"{parsed_url.scheme}://{parsed_url.netloc}/robots.txt"
    rp = RobotFileParser()
    rp.set_url(robots_url)
    try:
        rp.read()
        return rp.can_fetch("*", url)
    except:
        return False


def scrape_content(url):
    if not is_allowed_by_robots(url):
        raise PermissionError("Scraping not allowed by robots.txt for this URL.")

    response = requests.get(url)
    if response.status_code != 200:
        raise ValueError(f"Failed to fetch the page. Status code: {response.status_code}")

    soup = BeautifulSoup(response.text, "lxml")
    text = soup.get_text(separator='\n')
    return text.strip()


def get_robots_info(url):
    parsed_url = urlparse(url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
    robots_url = f"{base_url}/robots.txt"

    try:
        response = requests.get(robots_url)
        if response.status_code != 200:
            return "robots.txt not found", [], []

        lines = response.text.splitlines()
        user_agent = None
        allow = []
        disallow = []

        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().startswith("user-agent"):
                user_agent = line.split(":")[1].strip()
            elif line.lower().startswith("allow"):
                path = line.split(":")[1].strip()
                allow.append(path)
            elif line.lower().startswith("disallow"):
                path = line.split(":")[1].strip()
                disallow.append(path)

        return robots_url, allow, disallow

    except Exception as e:
        return f"Error reading robots.txt: {e}", [], []
